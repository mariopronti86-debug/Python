## Battaglia Navale

#Scopo dell'esercizio: Implementare una versione semplificata del gioco da tavolo "Battaglia Navale" utilizzando Python da terminale. Il gioco consisterà in un giocatore contro il computer.  
  
#Regole del gioco:**  
#- Il campo di gioco sarà una griglia quadrata di dimensioni predefinite (ad esempio 5x5).  
#- Il giocatore e il computer avranno ciascuno una sola nave di dimensione predefinita (ad esempio lunga 3 celle) da posizionare sulla griglia.  
#- Le navi possono essere posizionate orizzontalmente o verticalmente, ma non diagonalmente.  
#- I giocatori si alterneranno nel tentativo di colpire la nave avversaria sparando su una cella della griglia.  
#- Se un colpo colpisce una nave avversaria, verrà segnalato come "colpito" (ad esempio con il simbolo 'X'), altrimenti verrà segnalato come "mancato" (ad esempio con il simbolo 'O').  
#- Il gioco termina quando una delle navi viene completamente colpita.  
#- Verrà visualizzato un messaggio finale che indica il vincitore del gioco. 
 
#Suggerimenti per l'implementazione:**  
#- Utilizzare una matrice per rappresentare la griglia di gioco.  
#- Nella prima versione, usate posizioni già determinate alla creazione della matrice.  
#- Visualizzare la griglia di gioco dopo ogni colpo effettuato.  
#- Mantenere un conteggio dei colpi effettuati per ciascun giocatore.


# Costanti --> sono variabili che non dovrebbero cambiare durante l'esecuzione del programma 
# Per convenzione (fra essere umani) sono scritte in Maiuscolo
# TODO per Vesione 2: Gestione giocatore umano, Aggiungere print di aiuto con un menù, Stampa delle statistiche, Implementare versione avanzata calcolo coordinate

import random

DIMENSIONE_GRIGLIA = 5 # Matrice quadrata 5x5
LUNGHEZZA_NAVE = 3
SIMBOLO_ACQUA = "~"
SIMBOLO_NAVE = "N"
SIMBOLO_COLPITO = "X"
SIMBOLO_MANCATO = "O"
DIR_ORIZZONTALE = "H" # Orizzontale
DIR_VERTICALE = "V" 


"""
    [["~","~","~","~","~" ], <-- Riga 0
    ["~","~","~","~","~" ],  <-- Riga 1
    ["~","~","~","~","~" ],  <-- Riga 2
    ["~","~","~","~","~" ],  <-- Riga 3
    ["~","~","~","~","~" ]]  <-- Riga 4
"""
def crea_griglia_vuota(): 
    griglia = []

    for riga in range(DIMENSIONE_GRIGLIA): 
        nuova_riga = []

        for colonna in range(DIMENSIONE_GRIGLIA): 
            nuova_riga.append(SIMBOLO_ACQUA)
        
        griglia.append(nuova_riga)

    return griglia

#TODO: nascondere le navi con un parametro nascondi_navi = False/True
#TODO: rendere più chiara la stampa
def stampa_griglia(griglia): 
    print() # Printa una riga separatrice

    for riga in griglia: 
        print(riga)

    print() # Printa una riga separatrice

def posiziona_navi(griglia, riga_inizio, colonna_inizio, direzione): 
    for i in range(LUNGHEZZA_NAVE): 
        if direzione == "H":
            griglia[riga_inizio][colonna_inizio+i] = SIMBOLO_NAVE
        else:
            griglia[riga_inizio+i][colonna_inizio] = SIMBOLO_NAVE

#TODO: Implementare controlli validità coordinate (vedi metodo .isDigit() e check se range è 0-4 + ciclo while)
def chiedi_coordinate(): 
    riga = int(input(f"Inserisci coordinata per la riga. Valore ammesso: 0 - {DIMENSIONE_GRIGLIA-1}: "))
    colonna = int(input(f"Inserisci coordinata per la colonna. Valore ammesso: 0 - {DIMENSIONE_GRIGLIA-1}: ")) 

    return [riga, colonna]

def esegui_colpo(griglia, riga, colonna):
    print(f"Sparando alla coordinata {riga}-{colonna}")
    
    cella_corrente = griglia[riga][colonna]

    # Qui ho già sparato in precedenza, potrei non considerla come una mossa valida
    if cella_corrente ==  SIMBOLO_COLPITO or cella_corrente ==SIMBOLO_MANCATO: 
        return "Già sparato in questa coordinata"
    
    if cella_corrente == SIMBOLO_NAVE:
       griglia[riga][colonna] = SIMBOLO_COLPITO
       return "Colpito"

    # Se sono arrivato fino a qui, avevo simbolo ACQUA
    griglia[riga][colonna] = SIMBOLO_MANCATO
    return "Mancato"

# Scorro tutta la mia matrice, se trovo anche solo una "N" vuol dire che non ho colpito tutta la nave
def nave_affondata(griglia):
    for riga in range(DIMENSIONE_GRIGLIA): 
        for colonna in range(DIMENSIONE_GRIGLIA): 
            if griglia[riga][colonna] == SIMBOLO_NAVE: 
                return False 
    return True

#TODO: Sfruttando la lista, evito di sparare due volte nella stessa posizione
def calcola_coordinate_computer(): 
    riga = random.randint(0,DIMENSIONE_GRIGLIA-1)
    colonna = random.randint(0,DIMENSIONE_GRIGLIA-1)

    return [riga, colonna]

# Funzione principale che gestisce il flusso del gioco e coordina tutte le altre sotto funzioni
def gioca(): 
    
    print("Benvenuti al gioco della Battaglia Navale - Versione 1")

    griglia_giocatore = crea_griglia_vuota()
    griglia_computer = crea_griglia_vuota()

    posiziona_navi(griglia_giocatore, 1, 0, DIR_ORIZZONTALE)
    posiziona_navi(griglia_computer, 0,1, DIR_VERTICALE)

    print("Tutte le navi sono state posizionate, inizia il gioco!")

    print("La tua plancia di gioco:")
    stampa_griglia(griglia_giocatore)

    # -- Inizializza contatore e stato del programma
    # "Inizializza" vuol dire dichiarare e dare un valore alla variabile, "Dichiara" solo la dichiarazione senza assegnare valore
    colpi_giocatore = 0
    colpi_computer = 0
    colpi_effettuati_computer = [] # Lista per tracciare le coordinate estratte dal computer
    gioco_finito = False # Finché questa variabile è falsa, continuo a giocare
    turno_giocatore = True # Per mia scelta, il giocatore umano inizia la partita

    # Il while continua finché la condizione è vera! Con condizione "not" il False diventa True
    while not gioco_finito: 

        # Da implementare subito gestione turno computer
        if turno_giocatore: 
            print("IL TUO TURNO!")

            print("[DEBUG] Plancia di gioco del computer")
            stampa_griglia(griglia_computer) # Nella v2 nascondo le navi con il flag nascondi_navi = True

            coordinate_attacco = chiedi_coordinate()
            riga_attacco = coordinate_attacco[0]
            colonna_attacco = coordinate_attacco[1]

            risultato_attacco = esegui_colpo(griglia_computer, riga_attacco, colonna_attacco)

            # Gestito risultato tra "Già  sparato", "Mancato" e "Colpito"
            if risultato_attacco == "Mancato": 
                print("..acqua! Mancato.")
                colpi_giocatore += 1
            elif risultato_attacco == "Colpito": 
                colpi_giocatore += 1

                if nave_affondata(griglia_computer): 
                    print("COMPLIMENTI! Hai vinto la partita")
                    gioco_finito = True
            else: 
                print(risultato_attacco) # Hai già sparato in questa posizione, non scalo le vite

            turno_giocatore = False # Passo il turno al computer
            stampa_griglia(griglia_computer)

        else: 
            coordinate_attacco = calcola_coordinate_computer()
            riga_attacco = coordinate_attacco[0]
            colonna_attacco = coordinate_attacco[1]

            risultato_attacco = esegui_colpo(griglia_giocatore, riga_attacco, colonna_attacco)

            if risultato_attacco == "Mancato": 
                print("Il computer ha mancato il colpo!")
                colpi_computer += 1
            elif risultato_attacco == "Colpito": 
                print(f"Il computer ti ha colpito la nave con posizione {riga_attacco}-{colonna_attacco}")

                colpi_computer += 1
                if nave_affondata(griglia_giocatore): 
                    print("HAI PERSO!")
                    gioco_finito = True
            else: 
                print(f"Il computer ha sparato dove aveva già provato")

            turno_giocatore = True # Passo il turno al giocatore
            print("La tua griglia dopo il turno del computer: ")
            stampa_griglia(griglia_giocatore)

gioca() 
