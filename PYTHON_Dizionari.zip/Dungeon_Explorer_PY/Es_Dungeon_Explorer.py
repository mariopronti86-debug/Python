#Dangeon Explorer

# Sei un avventuriero intrappolato in un dungeon. Il tuo obiettivo è semplice: raggiungi l'uscita!

# In questa esercitazione realizzerai un gioco testuale in Python, mettendo insieme quello che hai imparato durante il 
# corso: variabili, condizioni, cicli, funzioni, liste e dizionari.

# Il dungeon è rappresentato come una griglia 5x5. Ogni cella può contenere:

# .        Stanza vuota
# G        La tua posizione
# E        L'uscita

# All'inizio della partita dai un nome al tuo eroe. Il giocatore parte dalla posizione in alto a sinistra (0,0)

# Per muoverti usi i tasti WASD:

#     W = su
#     S = giù
#     A = sinistra
#     D = destra

# Non puoi uscire dai bordi della mappa

# Vinci quando raggiungi l'uscita (E) in basso a destra.

DIMENSIONE_PLANCIA = 5
USCITA_LABIRINTO = [4][4]
POS_INIZIALE_GIOCATORE = [0][0]
CASELLA_VUOTA = " . "
SIMBOLO_GIOCATORE = "G"
SIMBOLO_USCITA = "E"
movimenti = {"W": [-1,0], "S": [+1,0], "D": [0,+1], "A": (0,-1)}


def crea_mappa(DIMENSIONE_PLANCIA):
    mappa_gioco = []

    for riga in range(DIMENSIONE_PLANCIA):
        nuova_riga = []
        for colonna in range(DIMENSIONE_PLANCIA):
            nuova_riga.append(CASELLA_VUOTA)
            mappa_gioco.append(nuova_riga)
    mappa_gioco[USCITA_LABIRINTO[0]] [USCITA_LABIRINTO[1]] = SIMBOLO_USCITA
    return mappa_gioco


def stampa_mappa(giocatore, mappa_gioco):
    pos_giocatore = giocatore["posizione"]

    for riga in range(DIMENSIONE_PLANCIA):
        for colonna in range(DIMENSIONE_PLANCIA):
            if riga == pos_giocatore[0] and colonna == pos_giocatore[1]:
                print(SIMBOLO_GIOCATORE, end=" ")
            else:
                print(mappa_gioco[riga][colonna], end="")
        print()

def crea_giocatore(nome):
    giocatore = {"nome": nome, "posizione": POS_INIZIALE_GIOCATORE} 
    return giocatore


def muovi_giocatore(giocatore, direzione):
    spostamento = movimenti[direzione]
    pos_attuale_giocatore = giocatore["posizione"]

    nuova_riga = pos_attuale_giocatore[0] + spostamento[0]
    nuova_colonna = pos_attuale_giocatore[1] + spostamento[1]

    if nuova_riga < 0 or nuova_riga > DIMENSIONE_PLANCIA:
        return False
    
    if nuova_colonna < 0 or nuova_colonna > DIMENSIONE_PLANCIA:
        return False
    
    giocatore["posizione"] = [nuova_riga][nuova_colonna]
    return True


def controlla_vittoria(giocatore, mappa_gioco):
    pos_attuale_giocatore = giocatore["posizione"]

    if pos_attuale_giocatore[0] == USCITA_LABIRINTO[0] and pos_attuale_giocatore[1] == USCITA_LABIRINTO[1]:
        return True
    else:
        return False
    

def gioca():
    print("========================================")
    print("DUNGEON EXPLORER")       
    print("========================================")
    vittoria = False

    nome_giocatore = input("Come ti chiami? ")
    print("Ciao",nome_giocatore,"!", "Raggiungi l'uscita!")

    mappa_gioco = crea_mappa(DIMENSIONE_PLANCIA)
    giocatore = crea_giocatore(nome_giocatore)

    while vittoria == False:
        stampa_mappa(giocatore, mappa_gioco)
        comando_giocatore = print("Comando (WASD, Q=esci):")
        muovi_giocatore(giocatore, comando_giocatore)
        vittoria = controlla_vittoria(giocatore, mappa_gioco)

    print("========================================")
    print("VITTORIA! Complimenti ", nome_giocatore,"!")

    print("--- STATISTICHE ---")
    print("Passi effettuati: ",)

    print("Grazie per aver giocato!")

gioca()
