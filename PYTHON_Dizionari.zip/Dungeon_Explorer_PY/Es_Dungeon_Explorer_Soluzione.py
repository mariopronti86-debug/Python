# il primo numero è detto "Major version" --> Features che sono importanti e spesso non retrocompatibili
# Il secondo numero è detto "Minor version" --> Nuove features che si integrano nella versione corrente
VERSIONE_APPLICAZIONE = 1

DIMENSIONE_MAPPA = 10

SIMBOLO_CASELLA_VUOTA = "."
SIMBOLO_CASELLA_GIOCATORE = "G"
SIMBOLO_CASELLA_USCITA = "E"

CARATTERE_USCITA = "Q"

# DIMENSIONE_MAPPA-1 perchè voglio anche uscita parametrica in funzione della dim plancia
USCITA_LABIRINTO = [DIMENSIONE_MAPPA-1,DIMENSIONE_MAPPA-1 ]
POS_INIZIALE_GIOCATORE = [0,0]

MOVIMENTI = { "W": [-1,0],  "S": [1,0], "A": [0,-1],  "D": [0,1] }


# --------------------------------------------
# FUNZIONI PER GESTIRE LA MAPPA
# --------------------------------------------

# crea_mappa potrebbe accedere direttamente a DIMENSIONE_PLANCIA. Best practice: le funzioni
# accedono ai parametri
def crea_mappa(dim_plancia, carattere_casella_vuota, uscita_labirinto, carattere_casella_uscita):
    mappa = []
    
    for _ in range(dim_plancia): 
        nuova_riga = []
        for _ in range(dim_plancia): 
            nuova_riga.append(carattere_casella_vuota)
            
        mappa.append(nuova_riga)
    
    # Ricorda che uscita_labirinto è una lista di di numeri tipo [4,4]
    # mappa[4][4] = "E"
    mappa[uscita_labirinto[0]][uscita_labirinto[1]] = carattere_casella_uscita
        
    return mappa

def stampa_mappa(mappa, giocatore, carattere_giocatore):

    # Ricorda che giocatore è un dizionario --> accedo alla chiave "posizione"
    pos_giocatore = giocatore["posizione"]

    # Stampo intestazione della colonna in modo che escono i numeri
    print("  ", end=" ") # Do uno spazio per allineare le colonne
    for col in range ( len(mappa) ): 
        print(f"{col} ", end=" ")
    print()

    for riga in range ( len(mappa) ): 
        print(f"{riga} ", end=" ")

        for colonna in range(len(mappa)): 
            if riga == pos_giocatore[0] and colonna == pos_giocatore[1]: 
                print(f"{carattere_giocatore} ", end=" ")
            else: 
                print(f"{mappa[riga][colonna]} ", end=" ")
        print()

    print()

# --------------------------------------------
# FUNZIONI PER GESTIRE IL GIOCATORE
# --------------------------------------------

# se chiamo la def "crea giocatore" mi aspetto che abbia
# codice solo per crearlo il giocatore, non per chiedere il nome
def crea_giocatore(nome_validato, posizione_iniziale_mappa): 
    giocatore = {
        "nome": nome_validato,
        "posizione": posizione_iniziale_mappa
    }

    return giocatore

def valida_nome_giocatore(nome): 
    if nome == "" or nome.isspace():
        raise ValueError("Il nome non può essere vuoto!")
    
    if len(nome) > 20: 
        raise ValueError("Il nome non può superare i 20 caratteri!")
    
    if nome.isdigit(): 
        raise ValueError("Il nome non può contenere solo numeri!")
    
    return nome.strip()

def chiedi_nome_giocatore():

    while True: 
        try: 
            nome_gocatore = input("Inserisci il nome del tuo eroe: \n")
            nome_valido = valida_nome_giocatore(nome_gocatore)
            print("Ciao",nome_gocatore,"!", "Raggiungi l'uscita!")
            return nome_valido
        except ValueError as e: 
            print(f"Errore: {e}")
            print("Riprova..")


# --------------------------------------------
# FUNZIONI PER GESTIRE IL MOVIMENTO
# --------------------------------------------

# Controllo se comando è nella lista di comandi ammissibili
def valida_comando(comando, dizionario_comandi): 
    if comando not in dizionario_comandi and comando != CARATTERE_USCITA: 
        # @TODO: Creare stampa helper
        raise ValueError(f"{comando} non valido! Comandi disponibili: Q, W, S, A, D") 

    return comando 

def calcola_nuova_posizione(giocatore, direzione): 
    pos_giocatore_attuale = giocatore["posizione"]

    # Partendo dal comando (Es "W", mi prendo la lista degli offset)
    spostamento = MOVIMENTI[direzione] #TODO: prendere costante movimenti in input
    spostamento_riga = spostamento[0] # quanto mi devo spostare in riga, da -1 a +1
    spostamento_colonna = spostamento[1] # quanto mi devo spostare in colonna, da -1 a +1

    nuova_riga_pos_giocatore = pos_giocatore_attuale[0] + spostamento_riga
    nuova_colonna_pos_giocatore = pos_giocatore_attuale[1] + spostamento_colonna

    # Controllo che non sono uscito fuori dalla mappa
    if nuova_riga_pos_giocatore < 0: 
        raise IndexError("Non puoi andare più in alto!")
    if nuova_riga_pos_giocatore >= DIMENSIONE_MAPPA: #TODO: prendere dim mappa da parametro 
        raise IndexError("Non puoi andare più basso!")
    if nuova_colonna_pos_giocatore < 0: 
        raise IndexError("Non puoi andare più a sinistra!")
    if nuova_colonna_pos_giocatore >= DIMENSIONE_MAPPA: #TODO: prendere dim mappa da parametro 
        raise IndexError("Non puoi andare più a destra!")

    # se arrivo fino a qui, vuol dire che i valori sono validi e coerenti  con la mappa
    return [nuova_riga_pos_giocatore, nuova_colonna_pos_giocatore]

def muovi_giocatore(giocatore, direzione): 
    
    # in calcola_nuova_posizione ho  controllato PRIMA di invocare muovi_giocatore 
    # Vuol dire che sono sicuro di avere W,A,S oppure D
    try: 
        valida_comando(direzione,  MOVIMENTI) # Utente ha inserito un comando tra quelli validi ?

        nuova_posizione = calcola_nuova_posizione(giocatore, direzione)
        giocatore["posizione"] = nuova_posizione  # Aggiorno posizione giocatore
        return True

    except ValueError as e: 
        print(f"Errore comando: {e}")
        return False

    except IndexError as e: 
        print(f"Attenzione: {e}")
        return False # Movimento non andato a buon fine 


# --------------------------------------------
# FUNZIONI PER GESTIRE LO STATO DELL'APPLICAZIONE
# --------------------------------------------
def controlla_vittoria(giocatore, mappa, carattere_uscita): 
    posizione_giocatore_attuale = giocatore["posizione"]

    riga_giocatore = posizione_giocatore_attuale[0]
    colonna_giocatore = posizione_giocatore_attuale[1]

    if mappa[riga_giocatore][colonna_giocatore] == carattere_uscita: 
        return True

    return False

def gioca(): 
    print("=" * 50)
    print("DUNGEON EXPLORER")
    print("Versione applicazione: ", VERSIONE_APPLICAZIONE )
    print("Sei un avventuriero intrappolato in un dungeon. Il tuo obiettivo è semplice: raggiungi l'uscita!")
    print("=" * 50)

    try: 
        vittoria = False

        nome_giocatore = chiedi_nome_giocatore()
        giocatore = crea_giocatore(nome_giocatore, POS_INIZIALE_GIOCATORE)

        mappa = crea_mappa(DIMENSIONE_MAPPA, SIMBOLO_CASELLA_VUOTA, USCITA_LABIRINTO,SIMBOLO_CASELLA_USCITA )

        while not vittoria: 
            stampa_mappa(mappa, giocatore, SIMBOLO_CASELLA_GIOCATORE)
            # @TODO: Stampa stat su giocatore (Tempo di gioco, Mosse effettuate, Posizione sulla mappa..)

            comando = input("Inserisci comando (WASD per movimento, 'Q' per uscire): ").upper()

            # Senza metodo upper() avrei dovuto prevedere anche "q" in minuscolo
            if comando == CARATTERE_USCITA:
                print(f"{nome_giocatore} abbandona la partita..")
                break

            # @TODO: Validare il comando in muovi_giocatore. Se utente inserisce "gatto", deve tornare False
            movimento_valido = muovi_giocatore(giocatore, comando)

            # Se muovi_giocatore torna True
            if movimento_valido: 
                vittoria = controlla_vittoria(giocatore, mappa, SIMBOLO_CASELLA_USCITA)

            # Come scrivere if vittoria == True
            if vittoria:
                print(f"Complimenti {nome_giocatore}, hai vinto la partita!!!") 
                # @TODO: Stampa stat su giocatore (Tempo di gioco, Mosse effettuate, Posizione sulla mappa..)

    except KeyboardInterrupt: 
        print("Partita interrota dall'utente (Ctrl + C)")

    except Exception as e: 
        # Qualsiasi altro errore che non sono riuscito a gestire (imprevisto)
        print(f"Errore non previsto: {e}")
        print("A causa di questo errore non previsto, il gioco sta per terminare")

    finally: 
        # Questo blocco viene eseguito SEMPRE
        print("=" * 50)
        print(" FINE GIOCO: grazie per aver giocato :) ")

        # @TODO: Inserire statistiche ti gioco
        print("=" * 50)

# --------------------------------------------
# AVVIO APPLICAZIONE
# --------------------------------------------
gioca()