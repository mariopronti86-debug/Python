import time
import random

def range_random(end):
    x = time.time()

    lista = []

    for i in range(end):
        lista.append(random.randint(1, 100))

    print(f"Ci ha messo {time.time() - x:.8f}s")
    return lista

def bubbleSort(lista):
    x = time.time()

    for j in range(0, len(lista)-1):
        for i in range(0, len(lista)-1):
            if lista[i]>lista[i+1]:
                lista[i], lista[i+1] = lista[i+1], lista[i]

    print(f"Ci ha messo {time.time() - x:.8f}s")

def bubbleSort_while(lista):
    x = time.time()

    while True:

        swapped = False

        for i in range(0, len(lista)-1):
            if lista[i] > lista[i+1]:
                swapped = True
                lista[i], lista[i+1] = lista[i+1], lista[i]
                
        if swapped==False:
            break
    
    print(f"Ci ha messo {time.time() - x:.8f}s", lista)

def ascending_list(end):
    x = time.time()

    lista = []

    for i in range(end):
        lista.append(i)
    
    print(f"Ci ha messo {time.time() - x:.8f}s")

    return lista

def descending_list(end):
    x = time.time()

    lista = []

    for i in range(end, 0, -1):
        lista.append(i)
    
    print(f"Ci ha messo {time.time() - x:.8f}s")

    return lista

def sum_list(lista):
    x = time.time()

    sum = 0

    for i in lista:
        sum += i
    
    print(f"Ci ha messo {time.time() - x:.8f}s - Somma numeri:{sum}")   

def sum_list_v2(lista):
    x = time.time()

    total_sum = sum(lista)
    
    print(f"Ci ha messo {time.time() - x:.8f}s - Somma numeri:{total_sum}")   

def get_even_numbers(lista):
    x = time.time()

    even_numbers = []

    for i in lista:
        if i%2 == 0:
            even_numbers.append(i)
    
    print(f"Ci ha messo {time.time() - x:.8f}s - Quantita' numeri pari:{len(even_numbers)}/{len(lista)}")    

def pop_even_numbers(lista):
    x = time.time()

    even_numbers = []

    for i in lista:
        if i%2 == 0:
            numero = lista.pop(i)
            even_numbers.append(numero)
    
    print(f"Ci ha messo {time.time() - x:.8f}s - Quantita' numeri pari:{len(even_numbers)}/{len(lista)}")    




# Ci ha messo 0.02459550s
# Versione somma 1 - Ci ha messo 0.00178266s - Somma numeri:5049687
# Versione somma 2 - Ci ha messo 0.00032592s - Somma numeri:5041732
# Ci ha messo 0.00379848s - Quantita' numeri pari:50068/100000

# Ci ha messo 0.12464428s
# Versione somma 1 - Ci ha messo 0.00896263s - Somma numeri:25228766
# Versione somma 2 - Ci ha messo 0.00160193s - Somma numeri:25240496
# Ci ha messo 0.04227853s - Quantita' numeri pari:499922/1000000
# range_random(500000)

# Ci ha messo 0.25139213s
# Versione somma 1 - Ci ha messo 0.01784825s - Somma numeri:50544788
# Versione somma 2 - Ci ha messo 0.00323796s - Somma numeri:50559436
# Ci ha messo 0.02067065s - Quantita' numeri pari:250416/500000
# range_random(1000000)


# # Ci ha messo 0.00323629s a creare la lista.
# # ascending_list(100000)
# # Ci ha messo 0.00274301s - Somma numeri:5000050000
# # Ci ha messo 0.00226974s - Somma numeri:125000250000
# # Ci ha messo 0.03823447s - Quantita' numeri pari:500000/1000000
# print("100.000 elementi")

lista1 = range_random(100000)
lista2 = range_random(500000)
lista3 = range_random(1000000)

get_even_numbers(lista1)
get_even_numbers(lista2)
get_even_numbers(lista3)
# sum_list(lista1)
# sum_list_v2(lista1)
# get_even_numbers(lista1)

# # Ci ha messo 0.01820660s a creare la lista.
# # ascending_list(500000)

# print("500.000 elementi")

# lista1 = ascending_list(100000)
# lista2 = ascending_list(500000)
# lista3 = ascending_list(1000000)

# sum_list(lista2)
# sum_list_v2(lista2)
# get_even_numbers(lista2)

# # Ci ha messo 0.03861547s a creare la lista.
# # ascending_list(1000000)
# print("1.000.000 elementi")

# lista1 = descending_list(100000)
# lista2 = descending_list(500000)
# lista3 = descending_list(1000000)

# sum_list(lista3)
# sum_list_v2(lista3)
# get_even_numbers(lista3)