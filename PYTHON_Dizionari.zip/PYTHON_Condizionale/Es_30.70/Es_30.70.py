login = input("Enter Username: ")

if login == "admin":
    pwd = input("Enter Password: ")

    if pwd == "Python":
        print("Welcome!")
    elif pwd == "" or pwd == "Esc":
        print("Canceled")
    else:
        print("Wrong Password")

elif login == "" or login == "Esc":
    print("Canceled")
else:
    print("I don't know you")