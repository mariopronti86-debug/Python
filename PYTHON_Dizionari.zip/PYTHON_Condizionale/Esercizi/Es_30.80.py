import random

# Migliorie
#1 --> Rifattorizzare nome variabile da user a player
#2 --> Inserire controllo input utente OPPURE input utente a stringa e convertire a numero
#3 --> Inserire ciclo per giocare finchè utente non digita "Esc" e prevedere punteggio AI vs Player

ai_random_choise = random.randint(1,3)  # @TODO: Deve diventare Randomico

print("1: Rock, 2: Paper, 3: Scissor")
user_choise = int(input("Your Move: "))  #  Cambiare da User a Player ? 

print(f"AI Chose: {ai_random_choise}, Player Choise: {user_choise}")

if ai_random_choise == user_choise:
    print("Draw")

 # Sasso(1) batte Forbice (3)• Carta(2) batte Sasso(1) • Forbice(3) batte Carta(2) • Se sono uguali → Pareggio 4. Il risultato deve essere stampato come testo (es. “Hai vinto!”, “Hai perso!”, “Pareggio!”).   
elif (user_choise == 1 and ai_random_choise == 3) or (user_choise == 2 and ai_random_choise == 1) or (user_choise == 3 and ai_random_choise == 2):
    print("Player won!")
else:
    print("AI won!")