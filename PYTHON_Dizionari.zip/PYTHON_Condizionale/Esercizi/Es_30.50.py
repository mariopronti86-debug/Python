WEEKLY_HOURS = 40

rate = float(input("Inserisci la paga oraria: "))
hours = int(input("Inserisci le ore lavorate: "))

if hours > WEEKLY_HOURS:
    overtime = hours - WEEKLY_HOURS
    total_pay = WEEKLY_HOURS * rate + overtime * (rate * 1.5)
else:
    print(f"La paga settimanale per {hours} ore è di €{rate * hours}")