price = float(input("Inserisci il prezzo unitario del prodotto: "))
quantity = int(input("Inserisci la quantità: "))

if price > 0 and quantity > 0:
    total_cost = price * quantity
    print(f"Il costo totale è {total_cost}€")
    print("Il costo totale è " + str(total_cost) + "€")
    print("Il costo totale è ", total_cost, "€", sep = "")
else:
    print("Dati non corretti")