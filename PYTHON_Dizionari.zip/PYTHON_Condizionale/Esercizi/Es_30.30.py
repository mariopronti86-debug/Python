num1 = int(input("Inserisci il primo numero: "))
num2 = int(input("Inserisci il secondo numero: "))

num1_even = num1 % 2 == 0

if num1_even and num2 % 2 == 0:
    print("Entrambi i numeri sono pari")
else:
    print("Almeno un numero è dispari")