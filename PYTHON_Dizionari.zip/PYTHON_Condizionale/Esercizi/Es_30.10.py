base=float(input("inserisci base del triangolo: "))
altezza=float(input("inserisci altezza: "))
area_triangolo=(base * altezza)/2

print("area del triango:",area_triangolo)