import random

cpu_move = random.randint(1,3)

print("1) Sasso, 2) Carta, 3) Forbice")
player_move = int(input("Inserisci il numero corrispondente alla mossa: "))

print(f"Hai scelto {player_move}, Il computer ha scelto {cpu_move}")

if player_move - cpu_move == 1 or player_move - cpu_move == -2:
    print("Hai vinto!")
elif player_move == cpu_move:
    print("Pareggio!")
else:
    print("Hai perso!")