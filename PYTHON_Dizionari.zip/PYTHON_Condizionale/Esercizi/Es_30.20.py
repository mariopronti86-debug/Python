numero=int(input("inserisci un numero: "))

print("prima variante")
if (numero>=10 and numero<=20) or numero== 0:
    if (numero==0):
        print("numero uguale a 0 ")
    else:
        print("numero compreso tra 10 e 20 ")   

print("seconda variante")
if (numero>=10 and numero<=20):
    print("numero compreso tra 10 e 20 ")
elif numero==0:
    print("numero uguale a 0")