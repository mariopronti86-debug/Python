# ESERCIZIO 10.50: Scrivi un programma che, richiesta all’utente una temperatura in
# gradi Celsius, la converta in Fahrenheit e poi la visualizzi.
celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 9/5) + 32
print("Temperature in Fahrenheit:", fahrenheit)