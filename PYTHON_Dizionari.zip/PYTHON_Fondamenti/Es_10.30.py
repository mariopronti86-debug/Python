# ESERCIZIO 10.30: Scrivi un programma per richiedere all’utente ore di lavoro e tariffe
# orarie per calcolare la retribuzione lorda.
hours = float(input("Enter Hours: "))
rate = float(input("Enter Rate: "))
pay = hours * rate
print("Pay:", pay)