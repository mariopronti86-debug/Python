# ESERCIZIO 10.40: Supponiamo di eseguire le seguenti istruzioni di assegnazione:
# width = 17
# height = 12.0
width = 17
height = 12.0

result_1 = width // 2
result_2 = width / 2.0
result_3 = height / 3

print("Result 1:", result_1, "Type:", type(result_1))
print("Result 2:", result_2, "Type:", type(result_2))
print("Result 3:", result_3, "Type:", type(result_3))