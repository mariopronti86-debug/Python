# ESERCIZIO 10.20: Scrivi un programma che usi input per chiedere all’utente il proprio
# nome e poi dia loro il benvenuto.

name = input("Enter your name: ")
print("Hello", name)