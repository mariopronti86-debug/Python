#ESERCIZIO 4

#Data la lista: numeri = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#Estrai e stampa solo gli elementi in posizione pari (0, 2, 4, ...).
#Poi estrai e stampa solo gli elementi in posizione dispari.
#Output atteso:
#[1, 3, 5, 7, 9]
#[2, 4, 6, 8, 10]

numeri = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

pari = numeri[ :: 2]
dispari = numeri[1 :: 2]

print(pari)
print(dispari)