#ESERCIZIO 7

#Data la stringa: data = "15/03/2025"
#Dividi la data nei suoi componenti (giorno, mese, anno).
#Poi ricostruisci la data nel formato "2025-03-15" (anno-mese-giorno).
#Stampa il risultato.
#Output atteso: 2025-03-15

data = "15/03/2025"

giorno, mese, anno = data.split("/")

data_ricostruita = f"{anno}-{mese}-{giorno}"

print(data_ricostruita)