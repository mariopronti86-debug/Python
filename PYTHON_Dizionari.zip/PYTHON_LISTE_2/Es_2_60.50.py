#ESERCIZIO 5

#Data la lista: numeri = [5, 10, 15, 20, 25]
#Crea una nuova lista con gli stessi elementi ma in ordine inverso.
#Stampa entrambe le liste per verificare che l'originale non sia cambiata.
#Output atteso:
#Originale: [5, 10, 15, 20, 25]
#Invertita: [25, 20, 15, 10, 5]

numeri = [5, 10, 15, 20, 25]

#ordinati = (numeri[ :: -1])
inversa = numeri[:]

print(numeri)

inversa.reverse()
print(inversa)
