#ESERCIZIO 6

#Data la stringa: frase = "Python è un linguaggio fantastico"
#Dividi la frase in parole e salvale in una lista.
#Stampa la lista e il numero di parole.
#Output atteso:
#['Python', 'è', 'un', 'linguaggio', 'fantastico']
#Numero di parole: 5

frase = "Python è un linguaggio fantastico"

parole = frase.split()

print(parole)
print("Numero di parole: ", len(parole))