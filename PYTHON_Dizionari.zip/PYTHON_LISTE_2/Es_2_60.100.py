#ESERCIZIO 10

#Data la lista: parole = ["gatto", "cane", "uccello", "pesce", "cane", "gatto", "cane"]
#Verifica se la parola "cane" è presente nella lista.
#Trova in quale posizione compare la prima volta.
#Conta quante volte compare in totale.
#Stampa tutti i risultati.

parole = ["gatto", "cane", "uccello", "pesce", "cane", "gatto", "cane"]

parola_cercata = input("Inserisci la parola da cercare: ")

if parola_cercata in parole:
    posizione = parole.index(parola_cercata)

    conteggio = parole.count(parola_cercata)

    print(f"La parola cercata è presente nella lista.")
    print(f"La prima occorrenza della parola cercata è alla posizione: {posizione}")
    print(f"La parola cercata compare {conteggio} volte nella lista.")
else:
    print("La parola cercata non è stata trovata")

