#ESERCIZIO 3

#Data la lista: lettere = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
#Estrai e stampa gli elementi dalla posizione 2 alla 5 (esclusa).
#Estrai e stampa gli ultimi 3 elementi.
#Output atteso:
#['c', 'd', 'e']
#['f', 'g', 'h']

lettere = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']

print(lettere[2 : 5])
print(lettere[-3 : ])