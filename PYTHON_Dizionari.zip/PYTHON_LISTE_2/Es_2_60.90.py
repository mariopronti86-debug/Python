#ESERCIZIO 9

#Data la lista: prezzi = [23.5, 18.0, 45.2, 12.8, 67.3]
#Crea una nuova lista con i prezzi ordinati dal più basso al più alto.
#Verifica che la lista originale non sia stata modificata.
#Stampa entrambe le liste.
#Output atteso:
#Originale: [23.5, 18.0, 45.2, 12.8, 67.3]
#Ordinata: [12.8, 18.0, 23.5, 45.2, 67.3]

prezzi = [23.5, 18.0, 45.2, 12.8, 67.3]

ordinati = sorted(prezzi)

print(prezzi)
print(ordinati)