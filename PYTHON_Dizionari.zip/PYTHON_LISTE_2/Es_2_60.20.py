#ESERCIZIO 2

#Data la lista: numeri = [10, 20, 30, 40, 50, 60, 70, 80, 90]
#Estrai e stampa solo i primi 4 elementi.
#Output atteso: [10, 20, 30, 40]

numeri = [10, 20, 30, 40, 50, 60, 70, 80, 90]

print(numeri[ : 4])
