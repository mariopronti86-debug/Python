# ESERCIZIO 14 (difficile)

# Data la lista: numeri = [23, 45, 12, 67, 34, 89, 15, 56, 78, 90]
# Crea tre nuove liste:
# - Una con i numeri minori di 30
# - Una con i numeri compresi tra 30 e 70 (estremi inclusi)
# - Una con i numeri maggiori di 70
# Ordina ogni lista in ordine decrescente.
# Stampa tutte e tre le liste con il loro conteggio.
# Output atteso:
# Minori di 30: [23, 15, 12] - Conteggio: 3
# Tra 30 e 70: [67, 56, 45, 34] - Conteggio: 4
# Maggiori di 70: [90, 89, 78] - Conteggio: 3

numeri = [23, 45, 12, 67, 34, 89, 15, 56, 78, 90]

minori_30 = []
tra_30_70 = []
maggiori_70 = []

for n in numeri:
    if n < 30:
        minori_30.append(n)
    elif n <= 70:
        tra_30_70.append(n)
    else:
        maggiori_70.append(n)

# Ordina in ordine decrescente
minori_30.sort(reverse=True)
tra_30_70.sort(reverse=True)
maggiori_70.sort(reverse=True)

print("Minori di 30:", minori_30, "- Conteggio:", len(minori_30))
print("Tra 30 e 70:", tra_30_70, "- Conteggio:", len(tra_30_70))
print("Maggiori di 70:", maggiori_70, "- Conteggio:", len(maggiori_70))