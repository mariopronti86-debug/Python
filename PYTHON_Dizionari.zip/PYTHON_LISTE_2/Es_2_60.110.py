#ESERCIZIO 11

#Scrivi una funzione chiamata "raddoppia_valori(lista)" che prende una lista di numeri
#e moltiplica per 2 ogni elemento DELLA LISTA ORIGINALE (senza crearne una nuova).
#Testa la funzione con la lista: numeri = [5, 10, 15, 20]
#Stampa la lista prima e dopo la chiamata della funzione.
#Output atteso:
#Prima: [5, 10, 15, 20]
#Dopo: [10, 20, 30, 40]

def raddoppia_valori(lista):
    for i in range(len(lista)):
        lista[i] = lista[i] * 2
        
numeri = [5, 10, 15, 20]
print(numeri)
raddoppia_valori(numeri)
print(numeri)