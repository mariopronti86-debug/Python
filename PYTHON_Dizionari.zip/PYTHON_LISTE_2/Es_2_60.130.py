# ESERCIZIO 13

# Data la stringa CSV: vendite = "Gennaio:1200,Febbraio:1500,Marzo:1100,Aprile:1800"
# Estrai i nomi dei mesi in una lista e i valori numerici in un'altra lista.
# Calcola e stampa:
# - Il totale delle vendite
# - La media delle vendite
# - Il mese con le vendite più alte
# Output atteso:
# Mesi: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile']
# Valori: [1200, 1500, 1100, 1800]
# Totale: 5600
# Media: 1400.0
# Mese migliore: Aprile


vendite = "Gennaio:1200,Febbraio:1500,Marzo:1100,Aprile:1800"

coppie = vendite.split(",")

mesi = []
valori = []

for coppia in coppie:
    mesi.append(coppia.split(":")[0])
    valori.append(int(coppia.split(":")[1]))

print("Mesi: ", mesi)
print("Valori", valori)

print(f"Totale:  {sum(valori)}")
print(f"Media:  {sum(valori) / len(valori)}")

valore_massimo = max(valori)
indice_massimo = valori.index(valore_massimo)

print("Mese migliore: ", mesi[indice_massimo])