#ESERCIZIO 12

#Data la lista: originale = [1, 2, 3, 4, 5]
#Crea una vera copia della lista chiamata "copia".
#Modifica la copia aggiungendo il numero 10.
#Verifica che la lista originale non sia cambiata.
#Stampa entrambe le liste e verifica che siano due oggetti diversi.
#Output atteso:
#Originale: [1, 2, 3, 4, 5]
#Copia: [1, 2, 3, 4, 5, 10]
#Sono lo stesso oggetto? False

originale = [1, 2, 3, 4, 5]

copia = originale[:]

copia.append(10)

print("Originale:", originale)
print("Copia:", copia)
print("Sono lo stesso oggetto?", originale is copia)