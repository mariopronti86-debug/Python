#ESERCIZIO 8

#Data la lista: voti = [18, 22, 25, 28, 30, 24, 27]
#Calcola e stampa:
#- Il voto più alto
#- Il voto più basso
#- La somma totale dei voti
#- La media dei voti (con 2 decimali)

import statistics  #Si può fare anche con import statistics per calcolarela media

voti = [18, 22, 25, 28, 30, 24, 27]

voto_massimo = max(voti)
voto_minimo = min(voti)
totale = sum(voti)
media = sum(voti) / len(voti)

print("Il voto piu' alto è: ",voto_massimo)
print("Il voto piu' basso è: ",voto_minimo)
print(f"La somma totale dei voti è: {totale}")
print(f"La media dei voti è: {round(media,2)}")
#print(f"La media dei voti è: {statistics.mean(voti):.2f}")  # alternativa alla media di sopra