#ESERCIZI - LISTE PARTE 2


#ESERCIZIO 1

#Crea una lista contenente il numero 0 ripetuto 10 volte.
#Stampa la lista.
#Output atteso: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

lista = [0] * 10
print(lista)
