# Scrivi un programma che:

# Chiede all'utente il suo nome e la sua citta
# Salva queste informazioni nel file profilo.txt nel formato:
# Nome: Mario
# Citta: Roma
# Rilegge il file e stampa il contenuto a schermo



# Chiedere all'utente il nome e la città
nome = input("Inserisci il tuo nome: ")
citta = input("Inserisci la tua citta: ")


# Salvare le informazioni nel file 'profilo.txt'
with open("./90_10/profilo.txt", "w") as file:
    file.write(f"Nome: {nome}\n")
    file.write(f"Citta: {citta}\n")


# Confermare che il file è stato salvato
print("File salvato!")


# Rileggere il contenuto del file e stamparlo a schermo
print("\nContenuto del file:")
with open("./90_10/profilo.txt", "r") as file:
    contenuto = file.read()
    print(contenuto)