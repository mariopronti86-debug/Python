# Esercizio 90.40 - Registro Voti
# Crea un programma per gestire i voti degli studenti:

# L'utente puo inserire voti nel formato NomeStudente:Voto (es. "Mario:8")
# I voti vengono salvati nel file voti.txt in append (modalita "a")
# Il programma deve anche poter leggere tutti i voti e calcolare la media per ogni studente
# Formato del file voti.txt:

# Mario:8
# Anna:9
# Mario:7
# Anna:10
# Output atteso (per la visualizzazione):

# --- MEDIE STUDENTI ---
# Mario: 7.5
# Anna: 9.5
# Suggerimento: Usa un dizionario dove la chiave e il nome e il valore e una lista di voti.


def inserisci_voti():
    while True:
        # Chiediamo all'utente di inserire il voto
        input_voto = input("Inserisci il voto (NomeStudente:Voto) o 'fine' per terminare: ")
        
        if input_voto.lower() == 'fine':
            break
        
        # Scriviamo il voto nel file
        with open("./90_40/voti.txt", "a") as file:
            file.write(input_voto + "\n")
        
        print("Voto aggiunto.")

def calcola_medie():
    voti_dict = {}
    
    # Leggiamo i dati dal file
    with open("./90_40/voti.txt", "r") as file:
        for line in file:
            nome, voto = line.strip().split(":")
            voto = int(voto)
            
            # Aggiungiamo i voti nel dizionario
            if nome not in voti_dict:
                voti_dict[nome] = []
            voti_dict[nome].append(voto)
    
    # Calcoliamo e stampiamo le medie
    print("\n--- MEDIE STUDENTI ---")
    for nome, voti in voti_dict.items():
        media = sum(voti) / len(voti)
        print(f"{nome}: {media:.1f}")

# Funzione principale
def main():
    inserisci_voti()  # Aggiungi voti
    calcola_medie()   # Calcola e mostra medie

# Esegui il programma
    main()
