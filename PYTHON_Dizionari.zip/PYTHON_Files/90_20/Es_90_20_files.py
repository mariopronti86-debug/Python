# Esercizio 90.20 - Lista della Spesa
# Crea un programma che gestisce una lista della spesa:

# All'avvio, carica la lista dal file spesa.txt (se esiste)
# Mostra un menu con le opzioni:
# 1: Aggiungi elemento
# 2: Visualizza lista
# 3: Salva ed esci
# Quando l'utente sceglie di uscire, salva la lista nel file
# Suggerimento: Ogni elemento va su una riga separata nel file.

# Esempio di file spesa.txt:

# Pane
# Latte
# Uova


def carica_lista():
    """Carica la lista della spesa dal file spesa.txt (se esiste)."""
    try:
        with open("./90_20/spesa.txt", "r") as file:
            return file.readlines()  # Restituisce la lista letta dal file
    except FileNotFoundError:
        return []  # Se il file non esiste, restituisce una lista vuota


def salva_lista(lista_spesa):
    """Salva la lista nel file spesa.txt."""
    with open("./90_20/spesa.txt", "w") as file:
        file.writelines(lista_spesa)  # Scrive ogni elemento della lista in una riga


def aggiungi_elemento(lista_spesa):
    """Aggiunge un elemento alla lista della spesa."""
    elemento = input("Inserisci l'elemento da aggiungere: ")
    lista_spesa.append(elemento + "\n")  # Aggiunge l'elemento con una nuova riga


def visualizza_lista(lista_spesa):
    """Visualizza la lista della spesa."""
    if lista_spesa:
        print("\nLista della spesa:")
        print("".join(lista_spesa))  # Stampa tutti gli elementi della lista
    else:
        print("La lista è vuota.")


def mostra_menu():
    """Mostra il menu delle opzioni e restituisce la scelta dell'utente."""
    print("\nMenu:")
    print("1: Aggiungi elemento")
    print("2: Visualizza lista")
    print("3: Salva ed esci")
    return input("Scegli un'opzione (1-3): ")


def main():
    """Funzione principale che gestisce il programma della lista della spesa."""
    lista_spesa = carica_lista()  # Carica la lista all'avvio
    
    while True:
        scelta = mostra_menu()  # Mostra il menu e ottieni la scelta dell'utente

        if scelta == "1":
            aggiungi_elemento(lista_spesa)  # Aggiungi un nuovo elemento
        elif scelta == "2":
            visualizza_lista(lista_spesa)  # Visualizza la lista della spesa
        elif scelta == "3":
            salva_lista(lista_spesa)  # Salva la lista nel file
            print("Lista salvata. Uscita...")
            break  # Esci dal ciclo e termina il programma
        else:
            print("Opzione non valida, riprova.")


# Avvio del programma
main()


