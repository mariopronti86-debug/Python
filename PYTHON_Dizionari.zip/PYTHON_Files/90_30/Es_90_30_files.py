# Esercizio 90.30 - Contatore di Parole
# Scrivi un programma che:

# Legge il contenuto di un file di testo chiamato testo.txt
# Conta e stampa:
# Il numero totale di righe
# Il numero totale di parole
# Il numero totale di caratteri (esclusi gli spazi)
# Suggerimento: Usa split() per dividere una stringa in parole.

# Esempio - se testo.txt contiene:

# Ciao mondo
# Python e bello
# Output atteso:

# Righe: 2
# Parole: 5
# Caratteri: 24


# Apro il file e leggo tutto il suo contenuto


with open("./90_30/testo.txt", "r") as file:
    righe = 0
    parole = 0
    caratteri = 0
    
    # Leggo il file riga per riga
    for riga in file:
        righe += 1  # Conto il numero di righe
        parole += len(riga.split())  # Conto le parole nella riga
        caratteri += len(riga.replace(" ", ""))  # Conto i caratteri (senza gli spazi)

# Stampo i risultati
print("Righe:", righe)
print("Parole:", parole)
print("Caratteri:", caratteri)

