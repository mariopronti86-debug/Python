def scrivi_saluto():
    file = open("messaggio_benvenuto.txt", "a")
    file.write("Hello World in Append!\n")
    file.close()

def leggi_contenuto(): 
    file = open("messaggio_benvenuto.txt", "r")

    print("Contenuto del file:")

    # <_io.TextIOWrapper name='messaggio_benvenuto.txt' mode='r' encoding='UTF-8'>
    print(file)
    print(file.read())

    file.close()

for _ in range(100):
    scrivi_saluto()

# leggi_contenuto()


with open("messaggio_benvenuto.txt", "a") as file:
    file.write("FINE FILE")

# "r" è il default
with open("messaggio_benvenuto.txt", "r") as file:
    c = 0
    for riga in file: 
        print(f"Riga {c} del file: ", riga)
        c += 1


# FileNotFoundError: [Errno 2] No such file or directory: 'percorso_che_non_esiste.txt'
try: 
    with open("percorso_che_non_esiste.txt", "r") as file:
        contenuto_file = file.read()
        print(contenuto_file)

# [Errno 2] No such file or directory: 'percorso_che_non_esiste.txt' ma non crasha l'applicativo
except FileNotFoundError as err: 
    print(err)
finally: 
    print("Fine esecuzione script")