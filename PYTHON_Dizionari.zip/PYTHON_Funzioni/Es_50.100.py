#50.100 - Funzioni che si chiamano
#Scrivi due funzioni:

#area_cerchio(raggio) che restituisca l'area del cerchio (π × raggio²)
#doppia_area_cerchio(raggio) che usi area_cerchio() e restituisca il doppio dell'area

#Usa math.pi per il valore di π. Calcola la doppia area per un cerchio di raggio 5.

import math

def area_cerchio(raggio):
    return math.pi * (raggio ** 2)

def doppia_area_cerchio(raggio):
    return area_cerchio(raggio) * 2

risultato = doppia_area_cerchio(5)
print(risultato)