#50.110 - Calcolatore costo viaggio
#Scrivi una funzione costo_viaggio(km, consumo_per_km, prezzo_carburante) che calcoli il costo totale di un viaggio. Dove:

#km = chilometri da percorrere
#consumo_per_km = litri consumati per km (es. 0.06 = 6 litri/100km)
#prezzo_carburante = prezzo al litro
#Calcola il costo per un viaggio di 350 km con consumo 0.07 l/km e carburante a 1.85 €/litro.

def costo_viaggio(km, consumo_per_km, prezzo_carburante):
    return km * consumo_per_km * prezzo_carburante

costo = costo_viaggio(350, 0.07, 1.85)
print("Il costo totale del viaggio è: ", round(costo,3), "€")
 