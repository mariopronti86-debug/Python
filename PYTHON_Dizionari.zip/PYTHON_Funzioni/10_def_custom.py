# Funzione senza parametri e return
def saluta_utente():
    print("Ciao Utente!")


# Funzione che prende un parametrop (il nome utente)
def saluta_utente(nome_utente):
    print(f"Ciao {nome_utente}")


def saluta_utenti(nome_utente1, nome_utente2, nome_utente3):
    # Variante 1 --> copia e incolla delle print
    print(f"Ciao {nome_utente1}")
    print(f"Ciao {nome_utente2}")
    print(f"Ciao {nome_utente3}")

    #Variante 2 --> copia e incolla delle print 
    saluta_utente(nome_utente1)
    saluta_utente(nome_utente2)
    saluta_utente(nome_utente3)


#Funzione che è specializzata nel sommare numeri. Non dovrebbe avere altri compiti
def somma_numeri(n1,n2):
   res =  n1 + n2
   return res


#Chiamata (o invocazione) della funzione
#saluta_utente()


# Note PY sa quale delle due invocare in base al nome e numero di parametri della funzione
saluta_utente("Davide")


#Saluta più utenti
saluta_utenti("Davide", "Simone", "Barbara")


somma_tot = somma_numeri(42,0) # Qui ho il return della somma della funzione
print("La somma totale è: ", somma_tot)


# Ordine con cui passo parametri conta
def sottrazione(a, b):
    return a - b


#Invertendo i parametri cambia il risultato
print(f"Sottrazione: {sottrazione(10,3)}")
print(f"Sottrazione: {sottrazione(3,10)}")


#tipo_saluto ha un valore predefinito (di default)
def saluta_predefinito(nome_utente, tipo_saluto = "Hola"):
    print(f"{tipo_saluto}, {nome_utente}")

def funzione_vuota():
    print("Hello")

saluta_predefinito("Davide")
saluta_predefinito("Davide", "Buongiorno")
saluta_predefinito(None, "Buongiorno")
saluta_predefinito(somma_numeri(42,0), "Buongiorno")
saluta_predefinito(funzione_vuota, "Buongiorno")
saluta_predefinito(funzione_vuota(), "Buongiorno")