#50.10 - Prima funzione semplice
#Scrivi una funzione saluta() che stampi "Benvenuto al corso di Python!". Chiamala 3 volte.

def saluta():
    print("Benvenuto al corso di Python!")

saluta()
saluta()
saluta()