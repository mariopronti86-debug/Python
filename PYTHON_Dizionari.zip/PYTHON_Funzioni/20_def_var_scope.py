# Visibilità delle variabili

variabile_globale = "Sono una variabile globale"

def funzione_custom():
    variabile_locale = "Sono una variabile locale"
    print("Variabile globale: ", variabile_globale)
    print("Variabile locale: ", variabile_locale)

funzione_custom()

#print(variabile_locale)
#NameError: name 'variabile_locale' is not defined. Did you mean: 'variabile_globale'?