#50.70 - Maggiore tra due numeri
#Scrivi una funzione maggiore(a, b) che restituisca il numero più grande tra i due parametri. Testala con diverse coppie di numeri.

def maggiore(a, b):
    if a > b:
        return a
    else:
        return b
    
print("Il maggiore tra 15 e 88 è: ", maggiore(15,88))
print(f"Il maggiore tra 56 e 6 è: {maggiore(56,6)}")
print("Il maggiore tra 2 e 1 è: ", maggiore(2,1))
print(f"Il maggiore tra 234 e 11 è: {maggiore(234,11)}")

