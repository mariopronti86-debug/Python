#50.90 - Calcolo sconto
#Scrivi una funzione applica_sconto(prezzo, percentuale_sconto) che restituisca il prezzo finale dopo lo sconto. Ad esempio, con prezzo=100 e sconto=20, deve restituire 80.0.

def applica_sconto(prezzo, percentuale_sconto):
    return prezzo * (1 - percentuale_sconto / 100)

print(applica_sconto(100, 20))   # 80.0
print(applica_sconto(79.90, 30)) # 55.93
print(applica_sconto(300, 17))   # 249.0