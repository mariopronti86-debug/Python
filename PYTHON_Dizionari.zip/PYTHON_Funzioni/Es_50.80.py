#50.80 - Pari o dispari
#Scrivi una funzione pari_o_dispari(numero) che restituisca la stringa "pari" se il numero è pari, "dispari" altrimenti. Testala con i numeri da 1 a 10.

def pari_o_dispari(numero):
    if numero % 2 == 0:
        return "pari"
    else:
        return "dispari"
    
for n in range(1, 11):
    print(n, "-->", pari_o_dispari(n))