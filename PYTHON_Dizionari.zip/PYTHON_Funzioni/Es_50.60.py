#50.60 - Calcolo IMC
#Scrivi una funzione calcola_imc(peso, altezza) che calcoli l'Indice di Massa Corporea (IMC = peso / altezza²). Peso in kg, altezza in metri. Calcola l'IMC per: peso=70kg altezza=1.75m e peso=85kg altezza=1.80m.

def calcola_imc(peso,altezza):
    return peso / (altezza ** 2) 

imc1 = calcola_imc(70, 1.75)
imc2 = calcola_imc(85, 1.80)

print("L'indice di Massa Corporea tra 70 e 1.75 è: ", imc1)  # circa 22.86
print(f"L' indice di Massa Corporea tra 85 e 1.80 è : {imc2}")  # circa 26.23