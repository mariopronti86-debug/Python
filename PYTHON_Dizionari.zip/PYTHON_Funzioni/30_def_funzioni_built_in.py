# Funzioni built-in --> Funzioni pre-costruite dentro Python, sono già implementate :)

print ("Ciao")
print("a", "b", sep = "0")

#len() --> Quanti caratteri ho nella stringa
print(len("Davide")) #6


#TypeError: object of type 'NoneType' has no len()
#print(len(None))


# Type --> Tipo della Variabile
print(type(None))  #<class 'NoneType'>
print(type("42"))  #<class 'str'>
print(type(42))  #<class 'int'>
print(type(True))  #<class 'bool'>

#int --> Prende una stringa e la converte in numero
print(type(int("42")))


#Round arrotonda un numero decimale, posso scegliere quante cifre decimali dopo la virgola
prezzo_merce = 314.562417861
print(round(prezzo_merce))
print(round(prezzo_merce,1))
print(round(prezzo_merce,3))


print(abs(-10)) #Valore assoluto del numero


#import è per importare dentro lo script il modulo
import random

numero_casuale = random.randint(1,10) # Numero casuale 1-10
print(numero_casuale)

for i in range(10):
    print(f"Numero casuale {i}: ", random.randint(1,10))

