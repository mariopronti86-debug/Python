#50.30 - Calcolo area rettangolo
#Scrivi una funzione area_rettangolo(base, altezza) che restituisca l'area. Calcola l'area di un rettangolo 12x8 e di uno 15x10, stampando i risultati.

def area_rettangolo(base, altezza):
    return base * altezza

area1 = area_rettangolo(12,8)
print(f"Area Rettangolo 1: {area1}")

area2 = area_rettangolo(15,10)
print(f"Area Rettangolo 2: {area2}")