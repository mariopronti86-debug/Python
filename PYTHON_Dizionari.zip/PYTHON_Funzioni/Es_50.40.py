#50.40 - Funzione con return
#Scrivi una funzione quadrato(n) che restituisca il quadrato di un numero. Usala per calcolare il quadrato di 5, di 12 e di 20, stampando ogni risultato.

def quadrato(n):
    return n * n

print("Il quadrato di 5 è:", quadrato(5))   #25
print(f"Il quadrato di 12 è: {quadrato(12)}")  #144
print("Il quadrato di 20 è: " + str(quadrato(20)))  #400