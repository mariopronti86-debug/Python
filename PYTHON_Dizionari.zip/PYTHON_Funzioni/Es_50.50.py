#50.50 - Conversione temperatura
#Scrivi una funzione celsius_to_fahrenheit(celsius) che converta da Celsius a Fahrenheit usando la formula: F = C × 9/5 + 32. Provala con 0°C, 25°C e 100°C.

def celsius_to_fahrenheit(celsius):
    return celsius * 9/5 + 32

print(celsius_to_fahrenheit(0))
print(celsius_to_fahrenheit(25))
print(celsius_to_fahrenheit(100))