#50.20 - Funzione con parametro
#Scrivi una funzione saluta_studente(nome) che stampi "Ciao [nome], buono studio!". Provala con almeno 3 nomi diversi.

def saluta_studente(nome_studente):
    print(f"Ciao {nome_studente}, buono studio!")

saluta_studente("Mario")
saluta_studente("Gioia")
saluta_studente("Elvio")