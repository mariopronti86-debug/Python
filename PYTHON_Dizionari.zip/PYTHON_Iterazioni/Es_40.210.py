#ESERCIZIO 40.210

#Scrivi un programma che stampi una piramide di numeri crescenti.

#Output:
#1
#1 2
#1 2 3
#1 2 3 4
#1 2 3 4 5

for i in range(1, 6):       # da 1 a 5 righe
    for j in range(1, i + 1):
        print(j, end=" ")
    print()                 # va a capo dopo ogni riga
    
    
    
#variante prof


rows = 6

for i in range (1, rows):
    for j in range(1, i + 1):
        print(j, end=" ")
    print()
