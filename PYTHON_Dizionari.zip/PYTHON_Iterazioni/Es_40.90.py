#ESERCIZIO 40.90
#Scrivi un programma che calcoli la somma di tutti i numeri da 1 a 100 usando
# un ciclo for.

somma = 0

for i in range(1, 101):  # range(1, 101) genera i numeri da 1 a 100 inclusi
    somma += i

print("La somma dei numeri da 1 a 100 è:", somma)