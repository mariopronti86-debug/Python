#ESERCIZIO 40.70
#Scrivi un programma che chieda all'utente un numero N e calcoli la somma di tutti i numeri da 1 a N usando un while.
#Esempio:#
#Inserisci N: 5
#Somma: 15  (perché 1+2+3+4+5 = 15)

num_utente = int(input("Inserisci Numero da Sommare? "))
somma=0
cont=0
while (cont<=num_utente):
    somma+=cont
    cont+=1
print(somma)



#variante son la somma dei numeri pari, dispari e la somma totale
counter = 1
sum_even = 0
sum_odd = 0
sum = 0

n = int(input("Scegli un numero: "))

while counter <= n:
    if counter % 2 == 0:
        sum_even += counter
    else:
        sum_odd += counter
        sum += counter
        counter += 1
  
print(f"La somma totale è: {sum}")
print(f"La somma dei numeri pari è: {sum_even}")
print(f"La somma dei numeri dispari è: {sum_odd}")