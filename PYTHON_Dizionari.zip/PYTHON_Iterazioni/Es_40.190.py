#ESERCIZIO 40.190
#Scrivi un programma che stampi un triangolo rovesciato di asterischi alto 5 righe.

#Output:
#* * * * *
#* * * *
#* * *
#* *
#*

for i in range(5,0,-1):
    print("* " * i)
    
    
    
#variante del professore
for i in range(5,0,-1):
    for j in range(i):
        print("*", end = "")