#ESERCIZIO 40.230

#Scrivi un programma che chieda all'utente quanti numeri vuole inserire.
#Poi chiedi di inserire i numeri uno per volta.
#Alla fine visualizza sia il valore più grande sia quello più piccolo.

#Nota: Assumiamo che l'utente inserisca sempre numeri validi

#Esempio:
#Quanti numeri? 5
#Numero 1: 23
#Numero 2: 5
#Numero 3: 67
#Numero 4: 12
#Numero 5: 45

#Massimo: 67
#Minimo: 5

max = None
min = None

total_number = int(input("Quanti numeri? "))

for i in range (total_number):
    n = int(input(f"Numero {i + 1}: "))
    if max == None or n > max:
        max = n
    if min == None or n < min:
        min = n 
print("Massimo: ", max)
print("Minimo: ", min)
    
