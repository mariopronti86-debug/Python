#ESERCIZIO 40.100
#Scrivi un programma che conti quanti multipli di 3 ci sono tra 1 e 50.
#--------------------------------------------------------------------------------

counter_mul_3 = 0

for i in range(1, 51):  # da 1 a 50 inclusi
    if i % 3 == 0:      # se il resto della divisione per 3 è 0, è un multiplo di 3
        counter_mul_3 += 1

print("I multipli di 3 tra 1 e 50 =:", counter_mul_3)


#variante
for j in range(0,51,3):
    print(j)