#ESERCIZIO 40.290

#Scrivi un programma che stampi i primi 10 numeri della sequenza di Fibonacci.
#La sequenza inizia con 0, 1 e ogni numero successivo è la somma dei due precedenti.

#Output: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34


n = 9

f_n = 1

if n <= 2:
    print(f_n)
else:
    f_nm2 = 1
    f_nm1 = 1
    print("0,1,1", end = ",")
    for i in range(3,n + 1):
        f_n = f_nm1 + f_nm2
        f_nm2 = f_nm1
        f_nm1 = f_n
        print(f_n , end = ",") 
    print("Totale Fibonacci: ", f_n)
