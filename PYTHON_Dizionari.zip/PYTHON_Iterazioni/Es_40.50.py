#ESERCIZIO 40.50
#Scrivi un programma che chieda all'utente un numero e stampi la sua tabellina da 1 a 10.
#Esempio output per input 7:
#7 x 1 = 7
#7 x 2 = 14
#7 x 3 = 21
#...
#7 x 10 = 70

numero_utente = int(input("Inserisci numero della tabellina che vuoi stampare? "))
for(i) in range(1,11):
    print(f"{numero_utente} x {i} = {numero_utente*i}", end="  ")  #end per annullare "/n" per andare a capo, l'abbiamo fatto perchè ce l'ha chiesto la traccia, si poteva anche non mettere
    