#ESERCIZIO 40.300

#Scrivi un programma che calcoli il fattoriale di un numero N inserito dall'utente.
#Il fattoriale di N (scritto N!) è il prodotto di tutti i numeri da 1 a N.

#Esempio: 5! = 1 × 2 × 3 × 4 × 5 = 120

n = int(input("Inserisci un numero per calcolare il fattoriale: "))

fattoriale = 1

for i in range(1, n + 1):
    fattoriale *= i

print(f"Il fattoriale di {n} è {fattoriale}.")


print("--------------------------------------------")


#Variante prof

fattoriale = 1
valori_fattoriale = []
n = 5

for i in range(1, n+1):
    fattoriale *= i
    valori_fattoriale.append(i)
print(valori_fattoriale)
print(fattoriale)

for i in valori_fattoriale:
    print(f" {i} x", end = "")
print(f" = {fattoriale}")