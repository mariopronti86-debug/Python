#ESERCIZIO 40.310

#Scrivi un programma che stampi una piramide centrata di asterischi alta 5 righe.

#Output:
#    *
#   ***
#  *****
# *******
#*********

righe = 5

for i in range(1, righe + 1):
    # Calcola num asterischi sulla riga
    asterischi = 2 * i - 1
    # Calcola num spazi per centrare gli asterischi
    spazi = righe - i
    # Stampa riga centrata
    print(" " * spazi + "*" * asterischi)


print("------------------------------------")


#Variante prof
n = 5
for i in range(1, n + 1):
    for k in range(n - i):
        print(" ", end = "")
    for j in range(i):
        print("*", end = " ")
    print()