#ESERCIZIO 40.110
#Scrivi un programma che calcoli il prodotto (moltiplicazione) di tutti i numeri da 1 a 5.
#Risultato atteso: 120 (perché 1×2×3×4×5 = 120)
#--------------------------------------------------------------------------------

prodotto = 1
for i in range (1, 6):
    prodotto *= i
print("Il prodotto dei numeri da 1 a 5 è:", prodotto)
