#ESERCIZIO 40.250

#Scrivi un programma per calcolare l'età di un cane in anni canini.

#Regole:

#Per i primi 2 anni: 1 anno del cane = 10.5 anni umani
#Dopo i primi 2 anni: ogni anno del cane = 4 anni umani
#Esempio: Inserisci l'età del cane in anni: 5 L'età in anni canini è: 33.0 (Calcolo: 2 × 10.5 + 3 × 4 = 21 + 12 = 33)

eta_cane = float(input("Inserisci l'età dei cani in anni: "))

if eta_cane <= 2 :
    eta_umana = eta_cane * 10.5
else: 
    eta_umana = 2 * 10.5 + (eta_cane - 2) * 4
    
print(f"L'età dei cani in anni canini è: {eta_umana}") 


print("----------------------------------------------------")


# Variante professore
anni = int(input("Inserisci anni da convertire: "))  
anni_convertiti = None

#TODO: Inserire controllo anni > 0

if anni <= 2:
   anni_convertiti =  anni * 10.5  
else:
    anni_convertiti = (2 * 10.5) + ((anni - 2)*4)

print("Anni convertiti: ", anni_convertiti)