#ESERCIZIO 40.60
#Scrivi un programma che usi un ciclo while per contare da 1 a 5 e stampare ogni numero.
#--------------------------------------------------------------------------------


numero=1
while numero<=5:
     print(numero)
     numero+=1


print("--------------------------------------------------")


#Esercizio Variante mostrando solo numeri divisibili per 3 e ad ogni iterazione mostra la somma parziale  di tutti i numeri

count=1
while count <= 15:
     partial_sum = 0
     for i in range(count):
          partial_sum += i
     print("Somma parziale: ", partial_sum)

     if count % 3 == 0:
          print("Numero divisibile per 3 = ", count)
     count += 1