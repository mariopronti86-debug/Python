#ESERCIZIO 40.80
#Scrivi un programma che parta da 1 e continui a raddoppiare il numero finché non supera 1000.
#Stampa ogni valore.

#Esempio output:
#1
#2
#4
#8
#16
#...
#512
#1024

counter = 0
mult = 1

while mult <= 1000:
     mult *= 2
     counter += 1
     print(f"Il totale è: {mult}, il contatore: {counter}")
     print(f"counter: {counter}")
     
mult_2 = 1
         
for i in range(1,15):
     mult_2 *= 2
     print(f"Il totale è: {mult_2}, contatore: {i}")
