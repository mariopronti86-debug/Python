#ESERCIZIO 40.20
#Scrivi un programma che stampi solo i numeri pari da 0 a 20 usando range() con il passo.
#-------------------------------------------------------------------------------

for i in range(0,21,2):
    print(i)


print("-------------------------------------------")


#Variante con lo step
for i in range(1,21,1):
    if i % 2 == 0:
        print(i)


print("-------------------------------------------")


#Esercizio seguendo il flow chart

contatore = 0
while contatore <= 20:
    if contatore % 2 == 0:
        print(f"contatore: {contatore}")
    contatore+=1