#ESERCIZIO 40.180
#Scrivi un programma che stampi un triangolo rettangolo di asterischi alto 5 righe.

#Output:
#*
#* *
#* * *
#* * * *
#* * * * *

for i in range(1, 6):
    print("* " * i)
    
    
#variante del professore

CHAR_PRINT = "* "
rows = 6

for i in range(rows):
    for j in range(i):
        print(CHAR_PRINT, end = "")
    print()
    