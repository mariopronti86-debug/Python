#ESERCIZIO 40.240

#Scrivi un programma per indovinare un numero compreso tra 1 e 9.

#Il programma:
#1. "Pensa" un numero segreto (per ora usa un numero fisso, es. 7)
#2. Chiede all'utente di indovinare
#3. Se l'utente sbaglia, chiede di nuovo
#4. Se indovina, stampa "Hai indovinato!" e termina

#Variante A: Dai suggerimenti "Troppo alto!" o "Troppo basso!"

#Variante B: Prevedi un numero massimo di 5 tentativi. Se non indovina, stampa "Hai esaurito i tentativi!"

num_segreto = 7
num_giocatore = None
while True:
    num_giocatore = int(input("Indovina quale numero ho pensato: (click 0 Per Uscire): "))
    if num_giocatore == 0:
        break
    elif num_giocatore == num_segreto:
        print("Hai Indovinato!")
        break
    print("Non hai Indovinato!")
    

    
#variante mia
segreto = 7

while True:
    tentativo = int(input("Indovina il numero (1-9): "))

    if tentativo == segreto:
        print("Hai indovinato!")
        break
    else:
        print("Sbagliato, riprova!")