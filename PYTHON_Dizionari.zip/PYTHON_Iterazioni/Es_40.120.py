#ESERCIZIO 40.120
#Scrivi un programma che chieda all'utente quanti numeri vuole inserire, poi chieda di inserirli uno per volta e alla fine stampi il numero più grande.
#Esempio:
#Quanti numeri? 4
#Numero 1: 15
#Numero 2: 8
#Numero 3: 23
#Numero 4: 12
#Il maggiore è: 23

num = int(input("Quanti numeri vuole inserire? "))

max = 0

for i in range(1, num + 1):
    numero= int(input(f"Numero {i}: "))
    if num is 0 or numero > max:
        max=numero

print("Il maggiore è:", max)       



#variante del professore
#fabs (x) restituisce il valore assoluto di x

import math

max = None

user_num = math.fabs(int(input(f"Inserisci quanti numeri inserire: ")))

user_num = int(user_num)


for i in range(user_num):
    num = int(input(f"Inserire il  numero {i}: "))
    if max == None or num > max:
        #swap di una variabile
        max = num
print(f"Max is: {max}")
        