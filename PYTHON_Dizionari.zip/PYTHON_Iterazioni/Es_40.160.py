#ESERCIZIO 40.160
#Scrivi un programma che chieda all'utente di inserire 5 numeri. Se l'utente inserisce un numero negativo, salta quel numero (non contarlo) e chiedi il successivo. Alla fine stampa la somma dei soli numeri positivi inseriti.

pos_sum = 0
for i in range(5):
    numero_utente = int(input(f"Inserisci il numero {i+1}: "))
    if numero_utente < 0:
        continue
    pos_sum += numero_utente
print(f"La somma dei num pos è: {pos_sum}")


print("-------------------------------------------------")


#variante mia 
somma = 0
count = 0

while count < 5:
    numero = int(input("Inserisci un numero: "))
    
    if numero < 0:
        print("Numero negativo, non verrà contato.")
        continue  # salta il numero e NON incrementa il conteggio
    
    somma += numero
    count += 1   # conta solo i numeri positivi

print("La somma dei numeri positivi inseriti è:", somma)