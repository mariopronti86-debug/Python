#ESERCIZIO 40.260

#Scrivi un programma che stampi un quadrato vuoto 7x7 fatto di asterischi.
#Solo i bordi devono essere asterischi, l'interno deve essere vuoto.

#Output:
#* * * * * * *
#*           *
#*           *
#*           *
#*           *
#*           *
#* * * * * * *

lato = 7

for i in range(lato):
    if i == 0 or i == lato - 1:
        # Prima e ultima riga: tutti asterischi
        print("* " * lato)
    else:
        # Righe centrali: asterisco, spazi vuoti, asterisco
        print("*" + " " * (2 * lato - 3) + "*")


print("-------------------------------------------------------")


# variante prof
dim_matrice = 7

CARATTERE_DA_STAMPARE = '*'

def stampa_riga_completa(n):

    for _ in range(n):   # _ è una variante muta
        print(f"{CARATTERE_DA_STAMPARE}", end= " ")
    print()

def stampa_riga_parziale(n):
    for i in range(n):
        if i == 0 or i == (n-1):
            print(CARATTERE_DA_STAMPARE, end = " ")
        else:
            print(" ", end = " ")
    print()

for i in range(dim_matrice):
    if i == 0 or i == (dim_matrice - 1):
        stampa_riga_completa(dim_matrice)
    else:
        stampa_riga_parziale(dim_matrice)