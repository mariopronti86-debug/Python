#ESERCIZIO 40.320

#Scrivi un programma che chieda l'età all'utente ripetutamente finché non inserisce un valore valido (tra 0 e 120).
#Se il numero non è nel range, stampa "Età non valida!"
#Quando l'età è valida, stampa "Età registrata: [età]" e termina.

#Nota: Assumiamo che l'utente inserisca sempre numeri



def eta_valida(eta_utente):
    if eta_utente >= 0 and eta_utente <= 120:
        return True
    else:
        return False

while True:    
    eta = int(input("Inserisci la tua età: "))
    if not eta_valida(eta):
        print("Età non valida!")
    else:
        print(f"Età registrata: {eta}")
        break
