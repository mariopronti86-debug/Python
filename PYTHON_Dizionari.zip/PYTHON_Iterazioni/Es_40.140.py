#ESERCIZIO 40.140
#Scrivi un programma che stampi tutti i numeri da 1 a 20, ma salti (usando continue) i multipli di 3.
#Output atteso:
#1
#2
#4
#5
#7
#8
#10
#...
#--------------------------------------------------------------------------------

for num in range(1,21):
    if num % 3 == 0:
        continue  # salta i multipli di 3
    print(num) 