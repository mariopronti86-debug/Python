#ESERCIZIO 40.150
#Scrivi un programma che chieda all'utente di inserire lettere una alla volta. Quando viene inserita una vocale (a, e, i, o, u), il programma stampa "Vocale trovata!" e si ferma.


while True:
    lettera_utente = input("Inserisci lettera: ")
    if lettera_utente == "a" or lettera_utente == "e" or lettera_utente == "i" or lettera_utente == "o" or lettera_utente == "u":
        print("Vocale trovata!")
        break