#ESERCIZIO 40.280

#Scrivi un programma che chieda un numero all'utente e determini se è primo o no.
#Un numero è primo se è divisibile solo per 1 e per sé stesso.

#Suggerimento: usa un ciclo for per testare tutti i divisori da 2 a N-1.

numero = int(input("Inserisci un numero: "))

if numero < 2:
    print(f"{numero} non è un numero primo.")
else:
    primo = True

    for i in range(2, numero):
        if numero % i == 0:
            primo = False
            break

    if primo:
        print(f"{numero} è un numero primo.")
    else:
        print(f"{numero} non è un numero primo.")


print("------------------------------------------------------------")


# Variante prof con la funzione def

def controlla_se_primo(n, divisore):
    if (n % divisore) == 0:
        print("Divisore: ", i)
        return False
    else:
        return True
    
n = int(input("Inserisci un numero: "))

is_primo = True

for i in range(2,n):
    is_primo = controlla_se_primo(n, i)
    if is_primo == False:
        break

if is_primo == True:
    print("Il numero è primo")
else:
    print("Il numero non è primo")




