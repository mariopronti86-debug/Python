#ESERCIZIO 40.130
#Scrivi un programma che cerchi il numero 7 tra i numeri da 1 a 20.
#Quando lo trova, stampa "Trovato!" e interrompi il ciclo usando break.
#--------------------------------------------------------------------------------

for numero in range(1,21):
    if numero == 7:
        print("Trovato!")
        break  #esce dal ciclo
    else:
        print(f"Controllo il numero {numero}")



#variante
for i in range(1,21):
    print("Iterazione: ",i)
    if i == 7:
        print("Trovato!")
        break
    
    
#altra variante
print("#########################")

for i in range(1,21):
    for j in range(1,21):
        print("Iterazione: ",j)
        if j == 7:
            print("Trovato!")
            break