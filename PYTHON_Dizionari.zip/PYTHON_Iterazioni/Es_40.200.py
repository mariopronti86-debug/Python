#ESERCIZIO 40.200
#Scrivi un programma che stampi le tabelline da 1 a 5 usando cicli annidati.

#Output:
#1 x 1 = 1
#1 x 2 = 2
#...
#2 x 1 = 2
#2 x 2 = 4
#...
#5 x 10 = 50

counter = 1
while counter <= 5:
        print(f"La tabellina di {counter} è: ")
        for i in range(1,11):
            print(f"{counter} x {i} =",counter * i)
        counter += 1
    
    
#variante mia
for i in range(1, 6):        # tabelline da 1 a 5
    for j in range(1, 11):   # ogni tabellina fino a 10
        print(f"{i} x {j} = {i * j}")
    print()  # riga vuota tra una tabellina e l'altra (opzionale)