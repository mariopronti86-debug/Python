#ESERCIZIO 40.270

#Scrivi un programma che richieda username e password.

#Regole:
#1. Username: deve essere "Admin"
#   - Se è corretto, chiedi la password
#   - Se è sbagliato, stampa "Utente non riconosciuto" e termina

#2. Password: deve essere "Python123"
#   - Se è corretta, stampa "Benvenuto!"
#   - Se è sbagliata, stampa "Password errata"

#Variante A: Permetti 3 tentativi per la password. Al terzo errore stampa "Account bloccato!"

#Variante B: Permetti all'utente di digitare "esci" in qualsiasi momento per uscire dal programma.

#TODO: Fare variante con il for al posto del while
#TODO: Introdurre costanti, funzioni per controllo tentativi e uscita programma

tentativi_errati = 0
username = (input("Inserisci Username: "))

if username == "esci":
    print("Uscito dal programma!")

elif username != "Admin":
    print("Utente non Riconosciuto")

else:

    while True:
        password = (input("Inserisci Password: "))

        if password == "esci":
            print("Uscito dal programma!") 
            break

        elif password != "Python123":
            tentativi_errati += 1
            print("Password errata. Tentativi Rimasti: ", (3-tentativi_errati))

            if (3-tentativi_errati) == 0:
                print("Account Bloccato!")
                break
        else:
            print("Benvenuto")
            break
