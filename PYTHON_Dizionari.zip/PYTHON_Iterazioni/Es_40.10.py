#ESERCIZIO 40.10
#Scrivi un programma che stampi tutti i numeri da 1 a 10 usando un ciclo for.

#--------------------------------------------------------------------------------

for i in range(1,11):
    print(i)

print("-------------------------------------------")


#equivalente con il while

count=1
while count <= 10:  #or < 11
    print(count)
    count += 1      #or count = count + 1 