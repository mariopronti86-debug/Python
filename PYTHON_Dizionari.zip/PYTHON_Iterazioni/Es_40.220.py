#ESERCIZIO 40.220

#Scrivi un programma che legga numeri interi dall'utente fino a quando l'utente digita 0.
#Una volta digitato 0, visualizza:
#- Il totale (somma)
#- Quanti numeri sono stati inseriti
#- La media dei numeri

#Nota: Assumiamo che l'utente inserisca sempre numeri validi

#Esempio:
#Inserisci un numero (0 per terminare): 10
#Inserisci un numero (0 per terminare): 5
#Inserisci un numero (0 per terminare): 8
#Inserisci un numero (0 per terminare): 0

#Totale: 23
#Conteggio: 3
#Media: 7.67

somma = 0
conteggio = 0

while True:
    n = int(input("Inserisci un numero (0 per terminare): "))
    
    if n == 0:
        break
    
    somma += n
    conteggio += 1

# Calcolo della media (evitiamo divisione per zero, anche se l’esercizio assume numeri validi)
media = somma / conteggio if conteggio != 0 else 0

print("\nTotale:", somma)
print("Conteggio:", conteggio)
print("Media:",(media, 2))