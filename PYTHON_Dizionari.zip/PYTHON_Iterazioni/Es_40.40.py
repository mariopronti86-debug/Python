#ESERCIZIO 40.40

#Scrivi un programma che faccia un countdown da 10 a 1, poi stampi "VIA!".

#Suggerimento: usa range() con passo negativo.

for i in range(10, 0, -1):   # parte da 10, arriva a 1, passo -1
    print(i)

print("VIA!")