#ESERCIZIO 40.170
#Scrivi un programma che stampi un rettangolo 5x3 di asterischi.

#Output:
#* * * * *
#* * * * *
#* * * * *

CHAR_PRINT = "*"

rows = int(input("Inserisci quante righe della matrice: "))
coloums = int(input("Inserisci quante colonne della matrice: "))

for i in range(rows):
    for j in range(coloums):
        print(CHAR_PRINT, end = " ")
    print()
    
    
    
#variante
for riga in range(3):
    for colonna in range(5):
        print("*", end=" ")
    print()  # va a capo a fine riga