#ESERCIZIO 40.30
#Scrivi un programma che stampi solo i numeri dispari da 1 a 19 usando range() con il passo.
#--------------------------------------------------------------------------------

for i in range(1,20,2):
        print(i)
