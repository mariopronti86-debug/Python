# ESERCIZIO 19
# Data la lista: prezzi = [15.5, 20.0, 18.5, 22.0, 19.5]
# Aumenta ogni prezzo del 10% e crea una nuova lista con i prezzi aumentati
# Stampa entrambe le liste

prezzi = [15.5, 20.0, 18.5, 22.0, 19.5]

# Lista vuota per i prezzi aumentati
prezzi_aumentati = []

# Ciclo per aumentare ogni prezzo del 10%
for prezzo in prezzi:
    aumento = prezzo * 1.10  # Aumento del 10%
    prezzi_aumentati.append(aumento)

print("Lista dei prezzi originali:", prezzi)

prezzi_arrotondati = [round(prezzo, 2) for prezzo in prezzi_aumentati]

print("Lista dei prezzi aumentati del 10%:", prezzi_arrotondati)
