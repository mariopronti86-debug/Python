# ESERCIZIO 13
# Data la lista: studenti = ["Mario", "Laura", "Giovanni"]
# Usa enumerate() per stampare una classifica numerata (1°, 2°, 3°)

studenti = ["Mario", "Laura", "Giovanni"]
for i, s in enumerate(studenti):
    print(f"{i+1}° : {s}")