# ESERCIZIO 17
# Crea una lista vuota chiamata "pari"
# Usa un ciclo for con range() per aggiungere tutti i numeri pari da 0 a 20
# Stampa la lista finale

pari = []
for i in range(0,21,2):
    pari.append(i)

print(pari)