# ESERCIZIO 20
# Scrivi un programma che:
# 1. Crea una lista vuota chiamata "temperature"
# 2. Chiede all'utente di inserire 5 temperature (usa input() e float())
# 3. Calcola e stampa:
#    - la temperatura massima
#    - la temperatura minima
#    - la temperatura media
# 4. Conta quante temperature sono sopra i 20 gradi
# 5. Stampa tutte le temperature con il loro numero progressivo

temperature = []

# 2. Chiede all'utente di inserire 5 temperature
for i in range(5):
    temp = float(input(f"Inserisci la temperatura {i+1}: "))  
    temperature.append(temp)

# 3. Calcola e stampa la temperatura massima, minima e media
temperatura_massima = max(temperature)
temperatura_minima = min(temperature)
temperatura_media = sum(temperature) / len(temperature)

print(f"Temperatura massima: {temperatura_massima}°C")
print(f"Temperatura minima: {temperatura_minima}°C")
print(f"Temperatura media: {temperatura_media:.2f}°C")

# 4. Conta quante temperature sono sopra i 20 gradi
sopra_20 = sum(1 for t in temperature if t > 20)
print(f"Numero di temperature sopra i 20 gradi: {sopra_20}")

# 5. Stampa tutte le temperature con il loro numero progressivo
print("\nTemperature inserite:")
for i, temp in enumerate(temperature, start=1):
    print(f"Temperatura {i}: {temp}°C")