# ESERCIZIO 9
# Data la lista: nomi = ["Alice", "Bob", "Carlo", "Diana"]
# Rimuovi "Carlo" usando remove()
# Stampa la lista risultante

nomi = ["Alice", "Bob", "Carlo", "Diana"]
nomi.remove("Carlo")

print(nomi)