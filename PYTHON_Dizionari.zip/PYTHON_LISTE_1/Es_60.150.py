# ESERCIZIO 15
# Crea una matrice 2x3 (2 righe, 3 colonne) con i numeri da 1 a 6
# Stampa la matrice
# Stampa l'elemento in posizione [1][2]

matrice = [
    [1, 2, 3],  # prima riga
    [4, 5, 6]   # seconda riga
]

# Stampa della matrice
print("Matrice 2x3:")
for riga in matrice:
    print(riga)

# Stampa dell'elemento in posizione [1][2] (seconda riga, terza colonna)
print("\nElemento in posizione [1][2]:", matrice[1][2])