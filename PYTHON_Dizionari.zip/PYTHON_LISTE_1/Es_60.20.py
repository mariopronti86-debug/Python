# ESERCIZIO 2
# Crea una lista chiamata "numeri" con i numeri da 0 a 9 usando range()
# Stampa la lista


#Questo è quello che chiede l 'eserczio gli altri sono varianti
numeri = list(range(10))
print(numeri)


#Variante 1
def aggiungi_numeri(n, numeri):
    numeri.append(n)


#Variante 2
numeri2 = []
for i in range(10):
    numeri2.append(i)
print(numeri2)


#Fa parte della Variante 1
aggiungi_numeri(42,numeri)
print(numeri)