# ESERCIZIO 12
# Data la lista: parole = ["ciao", "mondo", "python"]
# Scrivi un ciclo for che stampa ogni parola con il suo indice
# Usa range() e len()

parole = ["ciao", "mondo", "python"]
for i in range(len(parole)):
    
    print(f"Indice {i}: {parole[i]}")