# ESERCIZIO 14
# Data la lista: voti = [18, 25, 30, 22, 28]
# Verifica se nella lista è presente un 30
# Stampa un messaggio appropriato

voti = [18, 25, 30, 22, 28]

if 30 in voti:
    print("Il voto 30 è presente nella lista!")
else:
    print("Il voto 30 non è presente nella lista.")