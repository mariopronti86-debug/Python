# ESERCIZIO 7
# Data la lista: animali = ["cane", "gatto", "cavallo"]
# Inserisci "coniglio" in posizione 1 usando insert()
# Stampa la lista

animali = ["cane", "gatto", "cavallo"]
animali.insert(1,"coniglio")  

print(animali)