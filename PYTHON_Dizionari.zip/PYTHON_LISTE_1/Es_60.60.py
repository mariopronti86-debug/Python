# ESERCIZIO 6
# Crea una lista vuota chiamata "numeri"
# Aggiungi i numeri 5, 10, 15 uno alla volta usando append()
# Stampa la lista finale

numeri = []
numeri.append(5)
numeri.append(10)
numeri.append(15)

print(numeri)
