# ESERCIZIO 3
# Data la lista: colori = ["rosso", "verde", "blu", "giallo"]
# Stampa il primo e l'ultimo colore


colori = ["rosso", "verde", "blu", "giallo"]

primo_colore = colori[0] 
ultimo_colore = colori[-1] 

print("Primo colore: ", primo_colore)
print("Ultimo colore: ", ultimo_colore)


#Variante Semplice
colori = ["rosso", "verde", "blu", "giallo"]

print(colori[0])
print(colori[-1])