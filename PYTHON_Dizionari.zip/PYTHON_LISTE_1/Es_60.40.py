# ESERCIZIO 4
# Data la lista: prezzi = [10, 25, 30, 15, 20]
# Stampa quanti prezzi ci sono nella lista

prezzi = [10, 25, 30, 15, 20]

count = 0

for p in prezzi:
    if p in prezzi:
        #check se p è un numero
        count += 1
print(count)

print(len(prezzi))