# ESERCIZIO 8
# Crea due liste: lista1 = [1, 2, 3] e lista2 = [4, 5, 6]
# Crea una terza lista "completa" che unisce lista1 e lista2
# Stampa la lista completa

lista1 = [1, 2, 3]
lista2 = [4, 5, 6]
lista_completa = lista1 + lista2

print(lista_completa)