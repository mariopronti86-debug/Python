# ESERCIZIO 10
# Data la lista: temperature = [18, 22, 25, 20, 19]
# Rimuovi l'ultimo elemento usando pop()
# Stampa l'elemento rimosso e la lista risultante

temperature = [18, 22, 25, 20, 19]
elemento_rimosso = temperature.pop()

print(elemento_rimosso,temperature)