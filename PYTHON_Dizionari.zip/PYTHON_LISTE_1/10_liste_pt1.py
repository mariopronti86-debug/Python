#Creo una lista vuota. Python alloca spazio in memoria usando un puntatore (indirizzo di dove la lista ha inizio)
lista_vuota = []

##Senza il dizionario non posso associare anche i nomi degli studenti in maniera efficiente
# lista_nomi = ["Anna","Mario","Andrea","Simona","Barbara"]
lista_voti = [30,28,30,25,21]

print(f"La lista dei voti è: {lista_voti}")


#Le liste in Python sono eterogenee (posso metter qualsiaisi tipo di dato)
#La lista non è tipizata
lista_mista = [3,None,[0,2,3],"Ultimo elemento"]


# TODO: Generare voti solo >= 18?
lista_vuota = list(range(10))  #range non considera l'ultimo numero
print(f"La lista vuota ora è: {lista_vuota}")

# Accesso posizionale
primo_voto = lista_voti[0] # posizionale perche accedo in posizione 0
ultimo_voto = lista_voti[-1] 

print("Primo voto: ", primo_voto)
print("Ultimo voto: ", ultimo_voto)


# Funzione len() --> Quanti elementi ci sono nella lista?  Attenzione non conta da 0
tot_elementi_lista = len(lista_voti)
print(tot_elementi_lista)

print(len(list([])))  # mi restituisce 0 perche creo una lista vuota

somma = 0
for v in lista_voti:
    somma += v

print(somma/len(lista_voti))

# TODO: Usare while per iterare la lista con len.

# Modifica elementi:
lista_voti[0] = "30L"  #Aggiornamento del primo voto
print(lista_voti)  #[30L,28,30,25,21]

# "30L" ha problema che è in stringa in una lista di numeri
lista_voti[0] = 31  
print(lista_voti)  #[31,28,30,25,21]


#Aggiungere elementi in lista

# Append
lista_voti.append(18) 
lista_voti.append(18) 
lista_voti.append(18) 
print(lista_voti)  # #[31,28,30,25,21,18,18,18]
print("Nuova lunghezza lista: ", len(lista_voti))  #Nuova lunghezza lista:  8

# Insert
# Nota: Append è un sottocaso della insert
lista_voti.insert(0, 31)
print(lista_voti)  #[31, 31, 28, 30, 25, 21, 18, 18, 18]

# Se indice è maggiore di quanti elementi ho, ma non da errore ma mette in coda
lista_voti.insert(42,30)  # In alternativa .insert(len(lista_voti),30)
print(lista_voti)  #[31, 31, 28, 30, 25, 21, 18, 18, 18, 30]


# Concatenazione
lista_1sw = ["Anna","Mario","Andrea"]
lista_2sw = ["Simona","Barbara","Luigi","Marco"]
lista_sw_completa = lista_1sw + lista_2sw

print(lista_sw_completa)  # ['Anna', 'Mario', 'Andrea', 'Simona', 'Barbara', 'Luigi','Marco]


# Elimina la prima concorrenza di Marco
lista_sw_completa.remove("Marco")
print(lista_sw_completa)  #['Anna', 'Mario', 'Andrea', 'Simona', 'Barbara', 'Luigi']


# Pop() rimuove ultimo elemnto dalla lista
elemento_rimosso = lista_sw_completa.pop()
print(elemento_rimosso,lista_sw_completa)  #Luigi ['Anna', 'Mario', 'Andrea', 'Simona', 'Barbara']

# Il metodo pop prende anche un indice specifico 
elemento_rimosso = lista_sw_completa.pop(2)
print(elemento_rimosso,lista_sw_completa)  # Andrea ['Anna', 'Mario', 'Simona', 'Barbara']

# del a differenza del pop , non torna l'elemento eliminato
del lista_sw_completa[1]
print(lista_sw_completa)  # ['Anna', 'Simona', 'Barbara']

#questo errore porta ad un errore di sintassi --> SyntaxError: invalid syntax  :(
#elemento_rimosso_del = del lista_sw_completa[1]
#print(elemento_rimosso_del,lista_sw_completa)

# Iterazioni
for s in lista_sw_completa:
    print(s, end = " ")  # end = " " non va a capo e rimuove quindi /n e stampo sulla stessa riga

print()    

for i, s in enumerate(lista_sw_completa):
    print(f"Studente in posizione {i+1}: {s}")


#Matrici bidimensionale(2N) --> Solo riga e colonna, tipo excel
matrice_2n = [
    [1,2,3,4],
    [4,5,6],
    [7,8,9]
]

# Nota: se invece della lista ho altri valori come True oppure un numero, ottengo questo errore: TypeError: 'bool' object is not iterable

for riga in matrice_2n:
    for elemento in riga:
        print(f"Riga attuale: {riga}, elemento: {elemento}")

