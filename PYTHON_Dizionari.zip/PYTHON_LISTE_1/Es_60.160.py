# ESERCIZIO 16
# Data la lista: numeri = [5, 12, 3, 18, 7, 9]
# Calcola e stampa:
# - la somma di tutti i numeri
# - la media
# - il numero più grande
# - il numero più piccolo

numeri = [5, 12, 3, 18, 7, 9]

# Calcolare la somma di tutti i numeri
somma = sum(numeri)

# Calcolare la media
media = somma / len(numeri)

# Trovare il numero più grande
numero_piu_grande = max(numeri)

# Trovare il numero più piccolo
numero_piu_piccolo = min(numeri)

# Stampa dei risultati
print("Somma di tutti i numeri:", somma)
print("Media dei numeri:", media)
print("Numero più grande:", numero_piu_grande)
print("Numero più piccolo:", numero_piu_piccolo)