# ESERCIZIO 1
# Crea una lista chiamata "frutti" contenente: "mela", "banana", "arancia"
# Stampa la lista


#Variante 1
def crea_lista_frutti():

    frutti = ["mela", "banana", "arancia"]
    return frutti
print(crea_lista_frutti())


#Questo è quello che chiede l 'eserczio gli altri sono varianti
frutti = ["mela", "banana", "arancia"]
print(frutti)


#Variante 2
frutti2 = []
frutti2.append("mela")
frutti2.append("banana")
frutti2.append("arancia")
print(frutti2)