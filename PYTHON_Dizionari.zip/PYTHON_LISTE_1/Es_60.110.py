# ESERCIZIO 11
# Data la lista: numeri = [10, 20, 30, 40, 50]
# Scrivi un ciclo for che stampa ogni numero della lista

numeri = [10, 20, 30, 40, 50]

for i in numeri:
    print(i, end = " ")