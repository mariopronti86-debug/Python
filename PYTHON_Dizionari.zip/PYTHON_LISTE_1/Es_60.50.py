# ESERCIZIO 5
# Data la lista: voti = [18, 22, 25, 28]
# Modifica il primo voto (indice 0) in 20
# Stampa la lista modificata

voti = [18, 22, 25, 28]
voti[0] = 20

print(voti)