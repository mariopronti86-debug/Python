# ESERCIZIO 18
# Data la lista: voti = [28, 25, 30, 27, 30, 29, 24, 30]
# Conta quante volte compare il voto 30 usando un ciclo for
# Stampa il risultato

voti = [28, 25, 30, 27, 30, 29, 24, 30]

conta_30 = 0

# Ciclo per scorrere la lista e contare quante volte compare il voto 30
for voto in voti:
    if voto == 30:
        conta_30 += 1

print("Il voto 30 compare", conta_30, "volte.")