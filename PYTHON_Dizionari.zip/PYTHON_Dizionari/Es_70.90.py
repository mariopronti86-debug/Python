# ESERCIZIO 9 - Analisi vendite
# Hai una lista di vendite, ogni vendita è un dizionario:
# vendite = [
#     {"prodotto": "laptop", "quantita": 2, "prezzo": 800},
#     {"prodotto": "mouse", "quantita": 5, "prezzo": 25},
#     {"prodotto": "laptop", "quantita": 1, "prezzo": 800},
#     {"prodotto": "tastiera", "quantita": 3, "prezzo": 50},
#     {"prodotto": "mouse", "quantita": 2, "prezzo": 25}
# ]
# Calcola:
# 1. Il totale incassato (quantità * prezzo per ogni vendita)
# 2. Quanti pezzi sono stati venduti per ogni prodotto
# 3. Qual è il prodotto più venduto (in quantità)

vendite = [
    {"prodotto": "laptop", "quantita": 2, "prezzo": 800},
    {"prodotto": "mouse", "quantita": 5, "prezzo": 25},
    {"prodotto": "laptop", "quantita": 1, "prezzo": 800},
    {"prodotto": "tastiera", "quantita": 3, "prezzo": 50},
    {"prodotto": "mouse", "quantita": 2, "prezzo": 25}
]





# 1. Il totale incassato (quantità * prezzo per ogni vendita)
totale_incassato = 0
for vendita in vendite:
    totale_incassato += vendita["quantita"] * vendita["prezzo"]


# 2. Quanti pezzi sono stati venduti per ogni prodotto
pezzi_per_prodotto = {}
for vendita in vendite:
    prodotto = vendita["prodotto"]
    quantita = vendita["quantita"]
    if prodotto not in pezzi_per_prodotto:
        pezzi_per_prodotto[prodotto] = quantita
    else:
        quantita += pezzi_per_prodotto[prodotto]
        pezzi_per_prodotto[prodotto] = quantita

# 3. Prodotto più venduto (in quantità)
prdotto_piu_venduto = []

prdotto_piu_venduto
for k, vendita in pezzi_per_prodotto.items():
    print(k,vendita)



print("Totale incassato:", totale_incassato)
print("Pezzi venduti per prodotto:", pezzi_per_prodotto)
print("Prodotto più venduto:")