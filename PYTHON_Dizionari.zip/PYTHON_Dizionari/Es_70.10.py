# ESERCIZIO 1 - Rubrica semplice
# Crea un dizionario "rubrica" con 3 contatti (nome -> telefono).
# Stampa il numero di un contatto a tua scelta.
# Aggiungi un nuovo contatto e stampa tutta la rubrica.

rubrica = {}

rubrica["Mario"] = "331345678"
rubrica["Luigi"] = "334532121"
rubrica["Osvaldo"] = "0884567654"

print(rubrica["Osvaldo"])  #0884567654