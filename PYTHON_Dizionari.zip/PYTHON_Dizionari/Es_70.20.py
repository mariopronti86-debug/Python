# ESERCIZIO 2 - Traduttore
# Crea un dizionario con 5 parole italiane come chiavi
# e le traduzioni in inglese come valori.
# Chiedi all'utente una parola italiana e stampa la traduzione.
# Se la parola non esiste, stampa "Parola non trovata".

traduzioni = {  
    "ciao": "hello",
    "amico": "friend",
    "casa": "house",
    "libro": "book",
    "gatto": "cat"
    }

parola = input(str("Inserisci una parola italiana: "))

if parola in traduzioni:
    print(f"La traduzione di {parola} è: {traduzioni[parola]}")
else:
    print("Parola non trovata")


#Inserisci una parola italiana: casa
#La traduzione di casa è: house


#Inserisci una parola italiana: hhh
#Parola non trovata
    