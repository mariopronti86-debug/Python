# ESERCIZIO 3 - Anagrafica
# Crea un dizionario "persona" con: nome, cognome, età, città.
# Stampa ogni informazione nel formato "chiave: valore"
# usando un ciclo for.

persona = {
    "nome" : "Luigi",
    "cognome": "Prezzemolo",
    "eta" : 56,
    "citta": "Catanzaro"
    }

for chiave, valore in persona.items():
    print(f"{chiave} : {valore}")

#nome : Luigi
#cognome : Prezzemolo
#eta : 56
#citta : Catanzaro
