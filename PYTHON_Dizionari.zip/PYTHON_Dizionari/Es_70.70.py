# ESERCIZIO 7 - Registro voti
# Crea un dizionario dove ogni chiave è il nome di uno studente
# e ogni valore è una LISTA di voti.
# Esempio: {"Mario": [28, 30, 25], "Anna": [30, 27]}
# Per ogni studente, calcola e stampa la media dei voti.

studenti = {"Mario" : [28, 30, 25], "Anna" : [30, 27], "Luigi" : [25,30,29]}

for nome, voti in studenti.items():
    print(f"{nome}: media {round(sum(voti)/len(voti),1)}") 

#Mario: media 27.7
#Anna: media 28.5
#Luigi: media 28.0