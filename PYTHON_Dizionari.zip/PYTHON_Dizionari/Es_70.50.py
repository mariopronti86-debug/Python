# ESERCIZIO 5 - Contatore di caratteri
# Chiedi all'utente una stringa.
# Conta quante volte appare ogni carattere (esclusi gli spazi).
# Stampa il risultato come dizionario.
# Esempio: "ciao ciao" -> {'c': 2, 'i': 2, 'a': 2, 'o': 2}

stringa = input("Inserisci una stringa: ")

caratteri = {}

for c in stringa:
    if c != ' ':
        if c in caratteri:
            caratteri[c] += 1
        else:
            caratteri[c] = 1

print(caratteri)