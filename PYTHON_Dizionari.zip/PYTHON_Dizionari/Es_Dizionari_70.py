rubrica = {}  # come creare un dizionario vuoto. in alternativa uso dict()

rubrica["Mario"] = "333-111222"

#{'Mario': '333-111222'}
print(rubrica)

rubrica["Mario"] = None  #Va in aggiornamento perchè già esiste
print(rubrica)

rubrica["Anna"] = "333-222333"
rubrica["Davide"] = "333-555666"

#{'Mario': None, 'Anna': '333-222333', 'Davide': '333-555666'}
print(rubrica)


#LEGGERE UN VALORE DA UN DIZIONARIO
print(rubrica["Anna"])  #333-222333
#print(rubrica["Chiave non esistente"])  #KeyError: 'Chiave non esistente'
print(rubrica.get("Chiave non esistente"))  #None


#CANCELLAZIONE DI UN DATO coppia chiave-valore
# Abbiamo 3 soluzioni: del, pop, clear
del rubrica["Anna"]
print(rubrica)  #{'Mario': None, 'Davide': '333-555666'}

numero_mario = rubrica.pop("Mario")  # se non c'è la K, otteniamo un KeyError
print(rubrica)  #{'Davide': '333-555666'}
numero_mario = rubrica.pop("Mario", "Chiave non esistente")
print(numero_mario) #Chiave non esistente

rubrica.clear()
print(rubrica)  # {}


# Mini Esercizi pratici
# Es1: Contare le occorenze di una parola

parole = ["ciao", "mondo", "ciao", "Python", "mondo", "java", "python"]
conteggio = {}

# Step 1 --> Itero sulle chiavi
for p in parole:
    conteggio[p] = conteggio.get(p, 0) + 1

print(conteggio)  #{'ciao': 2, 'mondo': 2, 'Python': 1, 'java': 1, 'python': 1}


# Es2: Data una collezione di studenti, stampare la media dei voi
studenti = {"Davide": [20,25,30], "Giulia": [30,30,31], "Bruno": {28,29,30}}

for nome, voti in studenti.items():
    print(f"{nome}: media {sum(voti)/len(voti):.1f}")   
#Davide: media 25.0
#Giulia: media 30.333333333333332
#Bruno: media 29.0
# :.1f --> Formatto ad un solo decimale, Giulia: media 30.3


# Es3: Flirtrare elementi pari da una lista in un dizionario
numeri = [1,2,3,3,3,4]
frequenza = {}

for n in numeri:
    if n % 2 == 0:
        frequenza[n] = frequenza.get(n, 0) + 1

print(frequenza)   #{2: 1, 4: 1}
                  
