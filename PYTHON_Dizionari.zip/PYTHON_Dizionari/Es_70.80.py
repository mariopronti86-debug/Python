# ESERCIZIO 8 - Fusione inventari
# Dati due dizionari:
# inventario1 = {"mele": 10, "pere": 5, "banane": 8}
# inventario2 = {"pere": 3, "arance": 12, "mele": 7}
# Crea un terzo dizionario che somma le quantità dei prodotti comuni
# e include tutti i prodotti di entrambi.
# Risultato atteso: {"mele": 17, "pere": 8, "banane": 8, "arance": 12}

inventario1 = {"mele": 10, "pere": 5, "banane": 8}
inventario2 = {"pere": 3, "arance": 12, "mele": 7}

inventario3 = {}

for prodotto, quantita in inventario1.items():
    inventario3[prodotto] = quantita

for prodotto, quantita in inventario2.items():
    if prodotto in inventario3:
        inventario3[prodotto] += quantita
    else:
        inventario3[prodotto] = quantita

print(inventario3)

#{'mele': 17, 'pere': 8, 'banane': 8, 'arance': 12}