# ESERCIZIO 4 - Aggiorna età
# Dato il dizionario: persone = {"Mario": 25, "Anna": 30, "Luca": 22}
# Chiedi all'utente un nome e una nuova età.
# Se il nome esiste, aggiorna l'età. Altrimenti aggiungi la persona.
# Stampa il dizionario aggiornato.

persone = {
    "Mario": 25,
    "Anna": 30, 
    "Luca": 22
    }

nome = input(str("Inserisci un nome: "))
nuova_eta = int(input(f"Inserisci una nuova età di {nome}: "))

if nome in persone:
    persone[nome] = nuova_eta
    print(f"L'età di {nome} è stata aggiornata a {nuova_eta}.")
else:
    persone[nome] = nuova_eta
    print(f"{nome} è stato aggiunto con età {nuova_eta}.")

print("Dizionario aggiornato: ")
print(persone)