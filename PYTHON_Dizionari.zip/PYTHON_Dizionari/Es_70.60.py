# ESERCIZIO 6 - Magazzino
# Crea un dizionario "magazzino" con almeno 4 prodotti e quantità.
# Esempio: {"mele": 50, "pere": 30, ...}
# Stampa solo i prodotti con quantità inferiore a 20.
# Calcola e stampa la quantità totale in magazzino.

magazzino = {
    "mele": 50,
    "pere": 30,
    "banane" : 69,
    "caffe" : 10,
    "patate" : 6,
    "cozze": 3
}

print("Prodotti con quantità inferiore a 20: ")

for prodotto, quantita in magazzino.items():
    if quantita < 20:
        print(f"{prodotto} : {quantita}")

quantita_totale = sum(magazzino.values())
print(f"Quantità totale in magazzino: {quantita_totale}")