# ESERCIZIO 10 - Gestione biblioteca
# Crea un sistema di gestione libri con un dizionario annidato:
# biblioteca = {
#     "ISBN001": {"titolo": "Il Nome della Rosa", "autore": "Eco", "disponibili": 3},
#     "ISBN002": {"titolo": "1984", "autore": "Orwell", "disponibili": 0},
#     ...
# }
# Implementa un menu con le seguenti opzioni:
# 1. Mostra tutti i libri disponibili (disponibili > 0)
# 2. Cerca libro per autore (chiedi autore, mostra tutti i suoi libri)
# 3. Prestito libro (chiedi ISBN, decrementa disponibili se > 0)
# 4. Restituzione libro (chiedi ISBN, incrementa disponibili)
# 5. Aggiungi nuovo libro
# 6. Esci
# Usa un ciclo while per il menu.

biblioteca = {
    "ISBN001": {"titolo": "Il Nome della Rosa", "autore": "Eco", "disponibili": 3},
    "ISBN002": {"titolo": "1984", "autore": "Orwell", "disponibili": 0},
    "ISBN003": {"titolo": "Titanic", "autore": "Schettino", "disponibili": 10},
    "ISBN004": {"titolo": "Shining", "autore": "Stephen King", "disponibili": 25},
}

