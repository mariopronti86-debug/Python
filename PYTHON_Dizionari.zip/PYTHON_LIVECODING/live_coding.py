# funzione built-in già disponibile dentro Python
print("Hello World!") # Stampo a terminale una Stringa

# nome_utente è una variabile che contiene una stringa
nome_utente = "Davide"

# numero_intero è una variabile che contiene un numero intero
numero_intero = 10
numero_decimale = 3.14

# Bug --> Errore nel codice
# debugging --> Attività di ricerca e correzione errore
# il + concatena una più stringhe
print("Hello " + nome_utente + ", welcome back!")
print("Your number:", numero_intero)
print(numero_decimale)

# Operazioni algebriche
# https://programming-25.mooc.fi/part-1/4-arithmetic-operations
num_1 = 5
num_2 = 3
result = num_1 + num_2 # Somma e non concatenazione come le stringhe
print("Result: ", result)

result = num_1 * num_2
print("Result: ", result)

result = num_1 / num_2
print("Result: ", result)

result = num_1 % num_2
print("Result: ", result)

result = str(10) + "10 " #cast della variabile ovvero cambio il tipo
print(result)

# Input funzione built-in di Python (me la trovo già fatta)
username = input("Insert your name: ")
print("Hello, " + username + "!")

age = input("Insert your age: ")
print("Your age: ", age)

new_age = int(age) + 9
print("Your real age: ", new_age)

# Interpolazione della stringa
print(f"Hello {username}, welcome back!")