# import è una "keyword" di python per rendere disponibile alcune funzionalità
# aggiuntive che altrimenti non lo sarebbero

# datetime è modulo di python per la gestione delle date 
# https://docs.python.org/3/library/datetime.html
# docs.python.org doc ufficiale di python
import datetime

#2025-11-03 10:12:58.012959
datetime_now = datetime.datetime.now()
print(datetime_now)

# https://it.wikipedia.org/wiki/Tempo_(Unix)
unix_epoch = datetime.datetime.now().timestamp()
print(unix_epoch)

teacher_birthday = datetime.date(1987,7,18)
print("Teacher Birthday: ", teacher_birthday)

print("Y: " + str(teacher_birthday.year))
print("M: " + str(teacher_birthday.month))
print("D: " + str(teacher_birthday.day))

date_1 = datetime.date(2025,11,1)
date_2 = datetime.date(2025,11,3)
difference = date_2 - date_1

# Difference:  2 days, 0:00:00
print("Difference: ", difference)