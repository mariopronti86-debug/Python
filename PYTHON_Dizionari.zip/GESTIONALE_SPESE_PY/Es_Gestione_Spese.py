# Gestionale Spese Personali - Versione 1

NOME_APP = "GESTIONALE SPESE PERSONALI"
VERSIONE = "1.0"

# =============================================================================
# FUNZIONI DI GESTIONE SPESA
# =============================================================================
def crea_spesa(id, descrizione, importo):
    spesa = { "id": id, "descrizione": descrizione, "importo": importo }

    return spesa

def aggiungi_spesa(lista_spese, spesa):
    lista_spese.append(spesa)

def trova_spesa_per_id(lista_spese, id_spesa):
    for spesa in lista_spese:
        if spesa["id"] == id_spesa:
            return spesa
    
    return None

def elimina_spesa(lista_spese, id_spesa):
    for i in range(len(lista_spese)):
        if lista_spese[i]["id"] == id_spesa:
            lista_spese.pop(i)
            return True
        
    return False

# =============================================================================
# FUNZIONI DI VISUALIZZAZIONE
# =============================================================================
def stampa_menu():
    print()
    print(f"=== {NOME_APP} v{VERSIONE} ===")
    print()
    print("1. Aggiungi spesa")
    print("2. Visualizza tutte le spese")
    print("3. Mostra riepilogo")
    print("4. Elimina spesa")
    print("5. Esci")
    print()

def stampa_spesa(spesa):
    print(f"ID: {spesa['id']}")
    print(f"Descrizione: {spesa['descrizione']}")
    print(f"Importo: {spesa['importo']:.2f}")


def stampa_elenco_spese(lista_spese):
    if len(lista_spese) == 0:
        print("Nessuna spesa registrata.")
        return

    print()
    print(f"{'ID':<5}| {'Descrizione':<20}| {'Importo':>10}")
    print("-" * 5 + "+" + "-" * 21 + "+" + "-" * 11)

    for spesa in lista_spese:
        print(f"{spesa['id']:<5}| {spesa['descrizione']:<20}| {spesa['importo']:>10.2f}")

    print()


# =============================================================================
# FUNZIONI DI CALCOLO
# =============================================================================
def calcola_totale(lista_spese):
    totale = 0
    for spesa in lista_spese:
        totale = totale + spesa["importo"]

    return totale

def calcola_media(lista_spese):
    if len(lista_spese) == 0:
        return 0

    totale = calcola_totale(lista_spese)
    media = totale / len(lista_spese)

    return media

def trova_spesa_massima(lista_spese):
    if len(lista_spese) == 0:
        return None

    spesa_max = lista_spese[0]

    for spesa in lista_spese:
        if spesa["importo"] > spesa_max["importo"]:
            spesa_max = spesa

    return spesa_max

def trova_spesa_minima(lista_spese):
    if len(lista_spese) == 0:
        return None

    spesa_min = lista_spese[0]

    for spesa in lista_spese:
        if spesa["importo"] < spesa_min["importo"]:
            spesa_min = spesa

    return spesa_min


# =============================================================================
# FUNZIONI DI INPUT E VALIDAZIONE
# =============================================================================
def chiedi_intero(messaggio):
    while True:
        valore_inserito = input(messaggio)

        try:
            numero = int(valore_inserito)
            return numero
            
        except ValueError:
            print("Errore: inserire un numero intero valido.")


def chiedi_decimale(messaggio):
    while True:
        valore_inserito = input(messaggio)

        try:
            numero = float(valore_inserito)

            if numero <= 0:
                print("Errore: l'importo deve essere maggiore di zero.")
            else:
                return numero

        except ValueError:
            print("Errore: inserire un numero valido.")


def chiedi_stringa_non_vuota(messaggio):
    while True:
        valore_inserito = input(messaggio)
        valore_pulito = valore_inserito.strip()  # Rimuove spazi iniziali e finali

        if len(valore_pulito) == 0:
            print("Errore: il campo non puo essere vuoto.")
        else:
            return valore_pulito


def chiedi_conferma(messaggio):
    while True:
        risposta = input(messaggio + " (s/n): ")
        risposta_lower = risposta.lower().strip()

        if risposta_lower == "s":
            return True
        elif risposta_lower == "n":
            return False
        else:
            print("Errore: rispondere 's' o 'n'.")

# =============================================================================
# FUNZIONI PER LE OPERAZIONI DEL MENU
# =============================================================================
def operazione_aggiungi(lista_spese, prossimo_id):
    print()
    print("--- NUOVA SPESA ---")

    descrizione = chiedi_stringa_non_vuota("Descrizione: ")
    importo = chiedi_decimale("Importo: ")

    nuova_spesa = crea_spesa(prossimo_id, descrizione, importo)
    aggiungi_spesa(lista_spese, nuova_spesa)

    print()
    print(f"Spesa aggiunta con successo! (ID: {prossimo_id})")

    return prossimo_id + 1

def operazione_visualizza(lista_spese):
    print()
    print("--- ELENCO SPESE ---")
    stampa_elenco_spese(lista_spese)

def operazione_riepilogo(lista_spese):
    print()
    print("=== RIEPILOGO SPESE ===")
    print()

    if len(lista_spese) == 0:
        print("Nessuna spesa registrata.")
        return

    totale = calcola_totale(lista_spese)
    media = calcola_media(lista_spese)
    spesa_max = trova_spesa_massima(lista_spese)
    spesa_min = trova_spesa_minima(lista_spese)

    print(f"Numero spese: {len(lista_spese)}")
    print(f"Totale speso: {totale:.2f}")
    print(f"Media per spesa: {media:.2f}")
    print()
    print(f"Spesa massima: {spesa_max['descrizione']} ({spesa_max['importo']:.2f})")
    print(f"Spesa minima: {spesa_min['descrizione']} ({spesa_min['importo']:.2f})")

def operazione_elimina(lista_spese):
    print()
    print("--- ELIMINA SPESA ---")

    if len(lista_spese) == 0:
        print("Nessuna spesa da eliminare.")
        return

    stampa_elenco_spese(lista_spese)

    id_da_eliminare = chiedi_intero("Inserisci l'ID della spesa da eliminare: ")

    spesa_trovata = trova_spesa_per_id(lista_spese, id_da_eliminare)

    if spesa_trovata is None:
        print(f"Errore: nessuna spesa trovata con ID {id_da_eliminare}")
        return

    print()
    print("Spesa selezionata:")
    stampa_spesa(spesa_trovata)
    print()

    if chiedi_conferma("Confermi l'eliminazione?"):
        elimina_spesa(lista_spese, id_da_eliminare)
        print("Spesa eliminata con successo!")
    else:
        print("Eliminazione annullata.")

def operazione_esci(lista_spese):
    totale = calcola_totale(lista_spese)

    print()
    print("Grazie per aver usato il Gestionale Spese!")
    print(f"Totale speso in questa sessione: {totale:.2f}")
    print()
    print("Arrivederci!")

# =============================================================================
# FUNZIONE PRINCIPALE
# =============================================================================
def main():
    lista_spese = []
    prossimo_id = 1
    programma_attivo = True

    # Ciclo principale
    while programma_attivo:
        stampa_menu()

        scelta = chiedi_intero("Scelta: ")

        if scelta == 1:
            prossimo_id = operazione_aggiungi(lista_spese, prossimo_id)

        elif scelta == 2:
            operazione_visualizza(lista_spese)

        elif scelta == 3:
            operazione_riepilogo(lista_spese)

        elif scelta == 4:
            operazione_elimina(lista_spese)

        elif scelta == 5:
            operazione_esci(lista_spese)
            programma_attivo = False

        else:
            print("Opzione non valida. Scegliere un numero da 1 a 5.")

main()